# Kelson International School Portal

A modern school management system built with Next.js, Supabase, and passkey authentication.

## Setup Instructions

### 1. Supabase Setup

1. Go to [Supabase](https://supabase.com) and create a new project
2. Once your project is created, go to Settings > API
3. Copy your project URL and anon key
4. Copy your service role key (keep this secret!)

### 2. Environment Variables

1. Copy `.env.local` to your project root
2. Replace the placeholder values with your actual Supabase credentials:

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project-id.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key_here
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_here

# Email Configuration (for application submissions)
EMAIL_USER=your-gmail@gmail.com
EMAIL_PASS=your-gmail-app-password
```

### 3. Email Setup (for Application Form)

To enable email functionality for application submissions:

1. **Gmail Setup:**
   - Use a Gmail account for sending emails
   - Enable 2-Factor Authentication on your Gmail account
   - Generate an App Password (not your regular Gmail password)

2. **Generate Gmail App Password:**
   - Go to your Google Account settings
   - Navigate to Security > 2-Step Verification > App passwords
   - Generate a new app password for "Mail"
   - Use this 16-character password as `EMAIL_PASS`

3. **Environment Variables:**
   ```env
   EMAIL_USER=your-gmail@gmail.com
   EMAIL_PASS=your-16-character-app-password
   ```

4. **Testing:**
   - If email credentials are not configured, applications will still be accepted
   - Application data will be logged to the console for manual processing
   - Users will receive a success message regardless

### 4. Database Setup

The database migrations are already included in the `supabase/migrations` folder. To apply them:

1. Install Supabase CLI: `npm install -g supabase`
2. Login to Supabase: `supabase login`
3. Link your project: `supabase link --project-ref your-project-id`
4. Push migrations: `supabase db push`

Or you can run the SQL migrations manually in your Supabase SQL editor.

### 4. Running the Application

```bash
npm install
npm run dev
```

### 5. Testing Authentication

Demo credentials for testing:
- Student ID: S12345
- Staff ID: T12345

## Features

- **Passkey Authentication**: Secure, passwordless login using WebAuthn
- **Role-based Access**: Different interfaces for students and staff
- **Assignment Management**: Create, submit, and grade assignments
- **Real-time Updates**: Live data synchronization with Supabase
- **Responsive Design**: Works on desktop and mobile devices

## Architecture

- **Frontend**: Next.js 13+ with App Router
- **Backend**: Supabase (PostgreSQL + Auth + Real-time)
- **Authentication**: WebAuthn/Passkeys via SimpleWebAuthn
- **Styling**: Tailwind CSS + shadcn/ui components
- **Database**: PostgreSQL with Row Level Security (RLS)

## Security Features

- Row Level Security (RLS) policies
- Passkey-based authentication
- Secure credential storage
- Role-based access control
- HTTPS-only cookies and sessions

## Deployment

This application can be deployed to:
- Vercel (recommended for Next.js)
- Netlify
- Any platform supporting Node.js

Make sure to set your environment variables in your deployment platform.