"use client";

import Image from "next/image";
import { Card } from "@/components/ui/card";
import { School, Book, Users, Award } from "lucide-react";

export default function AboutPage() {
  return (
    <main className="container mx-auto px-4 py-12">
      {/* Hero Section */}
      <div className="relative h-64 md:h-80 rounded-xl overflow-hidden mb-12">
        <Image
          src="/IMG-20250513-WA0024.jpg"
          alt="Kelson International School Campus"
          fill
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">About Our School</h1>
            <p className="text-xl max-w-2xl">Excellence in Education Since Our Foundation</p>
          </div>
        </div>
      </div>
      
      <div className="max-w-4xl mx-auto">
        <div className="prose prose-lg max-w-none mb-12">
          <p className="text-lg text-gray-700 leading-relaxed mb-6">
            Welcome to our educational institution, where we foster academic excellence, personal growth, and community engagement. Our commitment to providing quality education has made us a leading institution in shaping future leaders.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-12">
          <Card className="p-6">
            <div className="flex items-start gap-4">
              <School className="h-8 w-8 text-primary" />
              <div>
                <h3 className="text-xl font-semibold mb-2">Our Mission</h3>
                <p className="text-gray-600">
                  To provide exceptional education that empowers students to achieve their full potential and contribute meaningfully to society.
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-start gap-4">
              <Book className="h-8 w-8 text-primary" />
              <div>
                <h3 className="text-xl font-semibold mb-2">Academic Excellence</h3>
                <p className="text-gray-600">
                  We maintain high academic standards through innovative teaching methods and a comprehensive curriculum.
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-start gap-4">
              <Users className="h-8 w-8 text-primary" />
              <div>
                <h3 className="text-xl font-semibold mb-2">Community Values</h3>
                <p className="text-gray-600">
                  Our diverse and inclusive community fosters collaboration, respect, and mutual understanding.
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-start gap-4">
              <Award className="h-8 w-8 text-primary" />
              <div>
                <h3 className="text-xl font-semibold mb-2">Student Success</h3>
                <p className="text-gray-600">
                  We celebrate our students' achievements and provide comprehensive support for their future endeavors.
                </p>
              </div>
            </div>
          </Card>
        </div>

        <section className="bg-gray-50 rounded-lg p-8">
          <h2 className="text-2xl font-bold mb-4">Our History</h2>
          <p className="text-gray-700 mb-4">
            Since our founding, we have been dedicated to providing outstanding educational opportunities. Our institution has grown from humble beginnings to become a beacon of academic excellence and innovation.
          </p>
          <p className="text-gray-700">
            Today, we continue to build on this strong foundation, embracing new technologies and teaching methods while maintaining our core values and commitment to student success.
          </p>
        </section>
      </div>
    </main>
  );
}