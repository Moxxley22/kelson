"use client";

import Image from "next/image";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen, Brain, Clock, Users, Award, Palette } from "lucide-react";

export default function AcademicsPage() {
  return (
    <main className="container mx-auto px-4 py-8">
      <div className="space-y-8">
        {/* Hero Section */}
        <section className="text-center space-y-4">
          <div className="relative h-64 md:h-80 rounded-xl overflow-hidden mb-8">
            <Image
              src="/IMG-20250515-WA0007 copy.jpg"
              alt="Students in Science Laboratory"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
              <div className="text-center text-white">
                <h1 className="text-4xl font-bold tracking-tight mb-4">Academic Excellence</h1>
                <p className="text-xl max-w-2xl mx-auto">
                  Our comprehensive curriculum is designed to nurture intellectual curiosity,
                  critical thinking, and a love for learning at every stage of development.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Academic Programs */}
        <Tabs defaultValue="early-years" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="early-years">Early Years</TabsTrigger>
            <TabsTrigger value="primary">Primary School</TabsTrigger>
            <TabsTrigger value="secondary">Secondary School</TabsTrigger>
          </TabsList>

          <TabsContent value="early-years">
            <Card>
              <CardHeader>
                <CardTitle>Early Years Program (Ages 3-5)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2">
                  <Card>
                    <CardHeader className="flex flex-row items-center gap-4">
                      <Brain className="h-8 w-8 text-primary" />
                      <div>
                        <CardTitle>Learning Through Play</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        <li>Hands-on learning experiences</li>
                        <li>Social and emotional development</li>
                        <li>Early literacy and numeracy</li>
                        <li>Creative expression</li>
                      </ul>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row items-center gap-4">
                      <Clock className="h-8 w-8 text-primary" />
                      <div>
                        <CardTitle>Daily Schedule</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        <li>Morning circle time</li>
                        <li>Guided activities</li>
                        <li>Outdoor exploration</li>
                        <li>Rest and reflection</li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="primary">
            <Card>
              <CardHeader>
                <CardTitle>Primary School (Grades 1-6)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2">
                  <Card>
                    <CardHeader className="flex flex-row items-center gap-4">
                      <BookOpen className="h-8 w-8 text-primary" />
                      <div>
                        <CardTitle>Core Subjects</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        <li>Language Arts</li>
                        <li>Mathematics</li>
                        <li>Science</li>
                        <li>Social Studies</li>
                      </ul>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row items-center gap-4">
                      <Palette className="h-8 w-8 text-primary" />
                      <div>
                        <CardTitle>Enrichment Programs</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        <li>Art and Music</li>
                        <li>Physical Education</li>
                        <li>Technology</li>
                        <li>Foreign Languages</li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="secondary">
            <Card>
              <CardHeader>
                <CardTitle>Secondary School (Grades 7-12)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2">
                  <Card>
                    <CardHeader className="flex flex-row items-center gap-4">
                      <Award className="h-8 w-8 text-primary" />
                      <div>
                        <CardTitle>Academic Programs</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        <li>Advanced Mathematics</li>
                        <li>Sciences (Biology, Chemistry, Physics)</li>
                        <li>Literature and Composition</li>
                        <li>World Languages</li>
                      </ul>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row items-center gap-4">
                      <Users className="h-8 w-8 text-primary" />
                      <div>
                        <CardTitle>Student Development</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        <li>Leadership Opportunities</li>
                        <li>Career Guidance</li>
                        <li>Community Service</li>
                        <li>Personal Development</li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Additional Information */}
        <section className="grid gap-6 md:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle>Teaching Methodology</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Our experienced teachers use innovative teaching methods to engage
                students and promote deep understanding of concepts.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Assessment</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Regular assessments help track student progress and identify areas
                for additional support or enrichment.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Support Services</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We provide learning support, counseling, and enrichment programs
                to ensure every student reaches their full potential.
              </p>
            </CardContent>
          </Card>
        </section>
      </div>
    </main>
  );
}