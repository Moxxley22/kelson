"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CalendarDays, School, FileText, Users } from "lucide-react";

export default function AdmissionsPage() {
  return (
    <main className="container mx-auto px-4 py-8">
      <div className="space-y-8">
        {/* Hero Section */}
        <section className="text-center space-y-4">
          <h1 className="text-4xl font-bold tracking-tight">Begin Your Educational Journey</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Welcome to Kelson International School's admissions portal. We provide a nurturing environment
            for students from preschool through grade 12.
          </p>
        </section>

        {/* Application Process Tabs */}
        <Tabs defaultValue="early-years" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="early-years">Early Years</TabsTrigger>
            <TabsTrigger value="primary">Primary</TabsTrigger>
            <TabsTrigger value="secondary">Secondary</TabsTrigger>
          </TabsList>
          
          <TabsContent value="early-years">
            <Card>
              <CardHeader>
                <CardTitle>Early Years Program (Ages 3-5)</CardTitle>
                <CardDescription>
                  Preschool and Nursery admissions information
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2">
                  <Card>
                    <CardHeader className="flex flex-row items-center gap-4">
                      <CalendarDays className="h-8 w-8" />
                      <div>
                        <CardTitle>Age Requirements</CardTitle>
                        <CardDescription>Entry age guidelines</CardDescription>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        <li>Preschool: 3 years old by September 1st</li>
                        <li>Pre-Kindergarten: 4 years old by September 1st</li>
                        <li>Kindergarten: 5 years old by September 1st</li>
                      </ul>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row items-center gap-4">
                      <FileText className="h-8 w-8" />
                      <div>
                        <CardTitle>Required Documents</CardTitle>
                        <CardDescription>Application materials</CardDescription>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        <li>Birth Certificate</li>
                        <li>Immunization Records</li>
                        <li>Previous School Records (if any)</li>
                        <li>Parent Interview</li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="primary">
            <Card>
              <CardHeader>
                <CardTitle>Primary School (Grades 1-6)</CardTitle>
                <CardDescription>
                  Primary education admissions information
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2">
                  <Card>
                    <CardHeader className="flex flex-row items-center gap-4">
                      <School className="h-8 w-8" />
                      <div>
                        <CardTitle>Assessment Process</CardTitle>
                        <CardDescription>Evaluation steps</CardDescription>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        <li>Academic Assessment</li>
                        <li>English Language Proficiency</li>
                        <li>Student Interview</li>
                        <li>Class Visit Day</li>
                      </ul>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row items-center gap-4">
                      <Users className="h-8 w-8" />
                      <div>
                        <CardTitle>Required Documents</CardTitle>
                        <CardDescription>Application materials</CardDescription>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        <li>Previous School Records</li>
                        <li>Teacher Recommendations</li>
                        <li>Health Records</li>
                        <li>Passport Copy</li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="secondary">
            <Card>
              <CardHeader>
                <CardTitle>Secondary School (Grades 7-12)</CardTitle>
                <CardDescription>
                  Secondary education admissions information
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2">
                  <Card>
                    <CardHeader className="flex flex-row items-center gap-4">
                      <CalendarDays className="h-8 w-8" />
                      <div>
                        <CardTitle>Key Dates</CardTitle>
                        <CardDescription>Application timeline</CardDescription>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        <li>Early Application: November 1st</li>
                        <li>Regular Application: March 1st</li>
                        <li>Rolling Admissions: Based on availability</li>
                      </ul>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row items-center gap-4">
                      <FileText className="h-8 w-8" />
                      <div>
                        <CardTitle>Requirements</CardTitle>
                        <CardDescription>Application materials</CardDescription>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        <li>Academic Records (Last 2 Years)</li>
                        <li>English Proficiency Test</li>
                        <li>Mathematics Assessment</li>
                        <li>Student & Parent Interviews</li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Call to Action */}
        <section className="text-center space-y-4 py-8">
          <h2 className="text-2xl font-semibold">Ready to Join Our School Community?</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Start your child's journey at Kelson International School. Our admissions team is here to guide you through every step of the process.
          </p>
          <div className="flex gap-4 justify-center mt-4">
            <Button size="lg">
              <Link href="/apply">Apply Now</Link>
            </Button>
            <Button size="lg" variant="outline">
              Schedule a Visit
            </Button>
          </div>
        </section>
      </div>
    </main>
  );
}