import { NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';

export async function GET() {
  try {
    const applicationsDir = path.join(process.cwd(), 'applications');
    
    try {
      const files = await fs.readdir(applicationsDir);
      const jsonFiles = files.filter(file => file.endsWith('.json') && file !== 'dashboard.json');
      
      const applications = [];
      
      for (const file of jsonFiles) {
        const filePath = path.join(applicationsDir, file);
        const content = await fs.readFile(filePath, 'utf-8');
        const application = JSON.parse(content);
        applications.push(application);
      }
      
      // Generate CSV
      const csvHeaders = [
        'Application ID',
        'Student Name',
        'Grade',
        'Date of Birth',
        'Gender',
        'Nationality',
        'Student Email',
        'Student Phone',
        'Parent Name',
        'Parent Email',
        'Parent Phone',
        'Current School',
        'Status',
        'Submitted Date'
      ];
      
      const csvRows = applications.map(app => [
        app.id,
        `${app.data.firstName} ${app.data.lastName}`,
        app.data.gradeApplying,
        app.data.dateOfBirth || '',
        app.data.gender || '',
        app.data.nationality || '',
        app.data.email || '',
        app.data.phone || '',
        `${app.data.parentFirstName || ''} ${app.data.parentLastName || ''}`,
        app.data.parentEmail || '',
        app.data.parentPhone || '',
        app.data.currentSchool || '',
        app.status,
        new Date(app.submittedAt).toLocaleDateString()
      ]);
      
      const csvContent = [
        csvHeaders.join(','),
        ...csvRows.map(row => row.map(field => `"${field}"`).join(','))
      ].join('\n');
      
      return new NextResponse(csvContent, {
        headers: {
          'Content-Type': 'text/csv',
          'Content-Disposition': `attachment; filename="applications-${new Date().toISOString().split('T')[0]}.csv"`
        }
      });
      
    } catch (error) {
      return NextResponse.json(
        { error: 'No applications found' },
        { status: 404 }
      );
    }
  } catch (error) {
    console.error('Error exporting applications:', error);
    return NextResponse.json(
      { error: 'Failed to export applications' },
      { status: 500 }
    );
  }
}