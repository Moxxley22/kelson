import { NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';

export async function GET() {
  try {
    const applicationsDir = path.join(process.cwd(), 'applications');
    
    try {
      const files = await fs.readdir(applicationsDir);
      const jsonFiles = files.filter(file => file.endsWith('.json') && file !== 'dashboard.json');
      
      const applications = [];
      
      for (const file of jsonFiles) {
        const filePath = path.join(applicationsDir, file);
        const content = await fs.readFile(filePath, 'utf-8');
        const application = JSON.parse(content);
        applications.push(application);
      }
      
      // Sort by submission date (newest first)
      applications.sort((a, b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime());
      
      return NextResponse.json({ applications });
    } catch (error) {
      return NextResponse.json({ applications: [] });
    }
  } catch (error) {
    console.error('Error reading applications:', error);
    return NextResponse.json(
      { error: 'Failed to load applications' },
      { status: 500 }
    );
  }
}