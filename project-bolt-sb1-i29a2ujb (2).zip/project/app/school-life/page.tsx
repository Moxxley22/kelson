'use client';

import { Card, CardContent } from "@/components/ui/card";
import { Users, Trophy, Palette, BookOpen, Calendar, MapPin } from "lucide-react";

export default function SchoolLifePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            School Life at Kelson International
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Experience a vibrant community where learning extends beyond the classroom through 
            diverse activities, sports, and cultural programs.
          </p>
          <div className="w-full h-64 md:h-96 rounded-lg overflow-hidden shadow-xl mb-12">
            <img 
              src="/IMG-20250515-WA0016.jpg" 
              alt="Students enjoying school activities" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* Student Life Overview */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Discover Your Passion
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              From academic clubs to sports teams, arts programs to community service, 
              there's something for every student to explore and excel.
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4 mb-16">
            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <Users className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Student Clubs</h3>
              <p className="text-gray-600">Join diverse clubs and make lifelong friendships</p>
            </Card>
            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <Trophy className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Sports & Athletics</h3>
              <p className="text-gray-600">Compete and stay active with our sports programs</p>
            </Card>
            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <Palette className="w-12 h-12 text-purple-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Arts & Culture</h3>
              <p className="text-gray-600">Express creativity through various artistic mediums</p>
            </Card>
            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <BookOpen className="w-12 h-12 text-orange-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Academic Support</h3>
              <p className="text-gray-600">Get help and excel in your studies</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Extracurricular Activities */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Extracurricular Activities
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Explore your interests and develop new skills through our diverse range of clubs and activities.
            </p>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardContent className="p-4">
                <h4 className="font-semibold mb-2">Drama Club</h4>
                <p className="text-sm text-muted-foreground">Express creativity through theatrical performances and stage productions.</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <h4 className="font-semibold mb-2">Act Club</h4>
                <p className="text-sm text-muted-foreground">Develop acting skills and perform in school productions and community events.</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <h4 className="font-semibold mb-2">Music Ensemble</h4>
                <p className="text-sm text-muted-foreground">Collaborate in various musical groups including choir, band, and orchestra.</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <h4 className="font-semibold mb-2">Debate Team</h4>
                <p className="text-sm text-muted-foreground">Develop critical thinking and public speaking skills through competitive debates.</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <h4 className="font-semibold mb-2">Cantering</h4>
                <p className="text-sm text-muted-foreground">Learn horseback riding techniques and develop equestrian skills in a safe environment.</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <h4 className="font-semibold mb-2">Science Club</h4>
                <p className="text-sm text-muted-foreground">Explore scientific concepts through hands-on experiments and research projects.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* School Events */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              School Events
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Throughout the year, we host exciting events that bring our community together.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card className="p-6">
              <Calendar className="w-8 h-8 text-blue-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Annual Sports Day</h3>
              <p className="text-gray-600 mb-4">
                A day of friendly competition and school spirit with various athletic events.
              </p>
              <span className="text-sm text-blue-600 font-medium">March 2024</span>
            </Card>
            <Card className="p-6">
              <Palette className="w-8 h-8 text-purple-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Cultural Festival</h3>
              <p className="text-gray-600 mb-4">
                Celebrate diversity through music, dance, art, and international cuisine.
              </p>
              <span className="text-sm text-purple-600 font-medium">May 2024</span>
            </Card>
            <Card className="p-6">
              <BookOpen className="w-8 h-8 text-green-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Science Fair</h3>
              <p className="text-gray-600 mb-4">
                Students showcase innovative projects and scientific discoveries.
              </p>
              <span className="text-sm text-green-600 font-medium">October 2024</span>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-blue-600 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Join Our Community?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Discover all the opportunities waiting for you at Kelson International School.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
              Schedule a School Tour
            </button>
            <button className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors">
              Apply Now
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}