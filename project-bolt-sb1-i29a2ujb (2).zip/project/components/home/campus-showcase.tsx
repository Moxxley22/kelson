"use client";

import { useState } from "react";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "@/components/ui/section-heading";
import { cn } from "@/lib/utils";

interface CampusImage {
  src: string;
  alt: string;
  label: string;
}

export function CampusShowcase() {
  const images: CampusImage[] = [
    {
      src: "https://images.pexels.com/photos/256490/pexels-photo-256490.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      alt: "Main building",
      label: "Main Building",
    },
    {
      src: "https://images.pexels.com/photos/159775/library-la-trobe-study-students-159775.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      alt: "Library",
      label: "Library",
    },
    {
      src: "https://images.pexels.com/photos/2827400/pexels-photo-2827400.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      alt: "Sports Complex",
      label: "Sports Complex",
    },
    {
      src: "https://images.pexels.com/photos/356065/pexels-photo-356065.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      alt: "Science Labs",
      label: "Science Labs",
    },
    {
      src: "https://images.pexels.com/photos/354939/pexels-photo-354939.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      alt: "Arts Center",
      label: "Arts Center",
    },
  ];

  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <section className="py-16 md:py-24">
      <div className="container">
        <SectionHeading
          title="Our School"
          description="Take a virtual tour of our state-of-the-art facilities that provide the ideal environment for learning and growth."
        />
        
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="w-full lg:w-3/4">
            <div className="relative aspect-video overflow-hidden rounded-xl shadow-lg">
              <Image
                src={images[activeIndex].src}
                alt={images[activeIndex].alt}
                fill
                className="object-cover transition-all duration-500 ease-in-out"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              <div className="absolute bottom-0 w-full p-6 text-white">
                <h3 className="text-2xl font-bold">{images[activeIndex].label}</h3>
              </div>
            </div>
          </div>
          
          <div className="w-full lg:w-1/4 flex flex-row lg:flex-col gap-4 overflow-x-auto lg:overflow-x-visible pb-4 lg:pb-0">
            {images.map((image, index) => (
              <button
                key={index}
                className={cn(
                  "relative min-w-[200px] lg:min-w-0 aspect-video rounded-lg overflow-hidden border-2 transition-all",
                  activeIndex === index
                    ? "border-blue-700 dark:border-blue-400 shadow-md"
                    : "border-transparent opacity-70 hover:opacity-100"
                )}
                onClick={() => setActiveIndex(index)}
              >
                <Image
                  src={image.src}
                  alt={image.alt}
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <div className="absolute bottom-0 w-full p-2 text-white">
                  <p className="text-sm font-medium">{image.label}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
        
        <div className="mt-8 text-center">
          <Button size="lg" asChild>
            <a href="/school-life">Schedule a School Tour</a>
          </Button>
        </div>
      </div>
    </section>
  );
}