import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "@/components/ui/section-heading";
import { Calendar, ArrowRight } from "lucide-react";

interface NewsCardProps {
  image: string;
  date: string;
  title: string;
  excerpt: string;
  slug: string;
}

function NewsCard({ image, date, title, excerpt, slug }: NewsCardProps) {
  return (
    <div className="group relative flex flex-col overflow-hidden rounded-lg border bg-background transition-all hover:shadow-md">
      <div className="relative h-48 w-full overflow-hidden">
        <Image
          src={image}
          alt={title}
          fill
          className="object-cover transition-transform duration-300 group-hover:scale-105"
        />
      </div>
      <div className="flex flex-col space-y-2 p-6">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Calendar className="h-4 w-4" />
          <span>{date}</span>
        </div>
        <h3 className="line-clamp-2 text-xl font-semibold">{title}</h3>
        <p className="line-clamp-3 text-muted-foreground">{excerpt}</p>
        <Link
          href={`/news/${slug}`}
          className="inline-flex items-center gap-1 pt-2 text-blue-700 dark:text-blue-400 hover:underline"
        >
          Read More <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  );
}

export function NewsEvents() {
  const newsItems = [
    {
      image: "https://images.pexels.com/photos/8471835/pexels-photo-8471835.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      date: "May 15, 2025",
      title: "Annual Science Fair Winners Announced",
      excerpt: "Congratulations to all participants in this year's Science Fair. The projects showcased incredible creativity and scientific inquiry.",
      slug: "science-fair-winners",
    },
    {
      image: "https://images.pexels.com/photos/8614999/pexels-photo-8614999.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      date: "April 28, 2025",
      title: "Oakridge Debate Team Takes State Championship",
      excerpt: "Our varsity debate team secured the state championship title after an impressive performance in the final round against defending champions.",
      slug: "debate-team-championship",
    },
    {
      image: "https://images.pexels.com/photos/5212335/pexels-photo-5212335.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      date: "April 12, 2025",
      title: "Spring Arts Festival This Weekend",
      excerpt: "Join us for a celebration of student creativity featuring visual arts displays, musical performances, and theatrical productions.",
      slug: "spring-arts-festival",
    },
  ];

  const upcomingEvents = [
    {
      date: "May 25, 2025",
      title: "Graduation Ceremony",
      time: "10:00 AM - 12:00 PM",
      location: "Main Auditorium",
    },
    {
      date: "May 30, 2025",
      title: "Summer Athletic Camp Registration",
      time: "All Day",
      location: "Online",
    },
    {
      date: "June 5, 2025",
      title: "Parent-Teacher Association Meeting",
      time: "6:30 PM - 8:00 PM",
      location: "Conference Center",
    },
    {
      date: "June 15, 2025",
      title: "Summer School Begins",
      time: "8:30 AM",
      location: "Main Campus",
    },
  ];

  return (
    <section className="py-16 md:py-24">
      <div className="container">
        <div className="grid gap-16 md:grid-cols-3">
          <div className="md:col-span-2">
            <SectionHeading
              title="Latest News"
              align="left"
              className="mb-8"
            />
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {newsItems.map((item, index) => (
                <NewsCard key={index} {...item} />
              ))}
            </div>
            <div className="mt-8 flex justify-center md:justify-start">
              <Button variant="outline" asChild>
                <Link href="/news" className="inline-flex items-center gap-2">
                  View All News <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
          
          <div>
            <SectionHeading
              title="Upcoming Events"
              align="left"
              className="mb-8"
            />
            <div className="space-y-4">
              {upcomingEvents.map((event, index) => (
                <div 
                  key={index}
                  className="flex items-start gap-4 rounded-lg border p-4 hover:bg-muted/50 transition-colors"
                >
                  <div className="flex h-14 w-14 flex-none flex-col items-center justify-center rounded-md bg-blue-50 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400">
                    <span className="text-sm font-medium">
                      {event.date.split(" ")[0]}
                    </span>
                    <span className="text-xl font-bold">
                      {event.date.split(" ")[1].replace(",", "")}
                    </span>
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-medium">{event.title}</h4>
                    <div className="flex flex-col text-sm text-muted-foreground">
                      <span>{event.time}</span>
                      <span>{event.location}</span>
                    </div>
                  </div>
                </div>
              ))}
              <Button variant="outline" className="w-full mt-6" asChild>
                <Link href="/calendar" className="inline-flex items-center gap-2">
                  View Full Calendar <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}