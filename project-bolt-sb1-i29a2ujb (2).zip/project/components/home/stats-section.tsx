"use client";

import { useState, useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

interface StatItemProps {
  value: number;
  label: string;
  suffix?: string;
  delay?: number;
}

function StatItem({ value, label, suffix = "", delay = 0 }: StatItemProps) {
  const [count, setCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );
    
    if (ref.current) {
      observer.observe(ref.current);
    }
    
    return () => observer.disconnect();
  }, []);
  
  useEffect(() => {
    if (!isVisible) return;
    
    const timeout = setTimeout(() => {
      const duration = 2000;
      const increment = Math.ceil(value / (duration / 16));
      let currentCount = 0;
      
      const timer = setInterval(() => {
        currentCount += increment;
        if (currentCount >= value) {
          setCount(value);
          clearInterval(timer);
        } else {
          setCount(currentCount);
        }
      }, 16);
      
      return () => clearInterval(timer);
    }, delay);
    
    return () => clearTimeout(timeout);
  }, [isVisible, value, delay]);
  
  return (
    <div 
      ref={ref} 
      className={cn(
        "text-center transition-all duration-1000 ease-out",
        isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
      )}
    >
      <div className="text-4xl md:text-5xl font-bold text-blue-700 dark:text-blue-400">
        {count}{suffix}
      </div>
      <p className="mt-2 text-muted-foreground">{label}</p>
    </div>
  );
}

export function StatsSection() {
  return (
    <section className="py-16 md:py-24 border-y bg-white dark:bg-gray-950">
      <div className="container">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <StatItem value={1985} label="Established" delay={0} />
          <StatItem value={98} label="College Acceptance Rate" suffix="%" delay={200} />
          <StatItem value={15} label="Student-Teacher Ratio" suffix=":1" delay={400} />
          <StatItem value={52} label="Academic Programs" delay={600} />
        </div>
      </div>
    </section>
  );
}