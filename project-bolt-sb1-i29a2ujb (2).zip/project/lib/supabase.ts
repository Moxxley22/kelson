// This file has been removed as Supabase is no longer used in this application.
// All authentication and data management is now handled locally using localStorage.

export const createSupabaseClient = () => {
  throw new Error("Supabase has been removed from this application. Use local authentication instead.");
};

export const createSupabaseServerClient = () => {
  throw new Error("Supabase has been removed from this application. Use local authentication instead.");
};

export const createSupabaseServiceClient = () => {
  throw new Error("Supabase has been removed from this application. Use local authentication instead.");
};