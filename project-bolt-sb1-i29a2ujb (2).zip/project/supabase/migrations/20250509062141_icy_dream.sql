/*
  # Create assignments and submissions tables

  1. New Tables
    - `assignments`
      - `id` (uuid, primary key)
      - `title` (text)
      - `description` (text)
      - `due_date` (timestamptz)
      - `teacher_id` (uuid, references auth.users)
      - `created_at` (timestamptz)
      - `class_id` (text)
      - `max_score` (integer)
    
    - `submissions`
      - `id` (uuid, primary key)
      - `assignment_id` (uuid, references assignments)
      - `student_id` (uuid, references auth.users)
      - `content` (text)
      - `submitted_at` (timestamptz)
      - `score` (integer)
      - `feedback` (text)

  2. Security
    - Enable RLS on both tables
    - Add policies for teachers and students
*/

-- Create assignments table
CREATE TABLE assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  due_date timestamptz NOT NULL,
  teacher_id uuid NOT NULL REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  class_id text NOT NULL,
  max_score integer NOT NULL DEFAULT 100,
  CONSTRAINT valid_score CHECK (max_score > 0)
);

-- Create submissions table
CREATE TABLE submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assignment_id uuid NOT NULL REFERENCES assignments(id) ON DELETE CASCADE,
  student_id uuid NOT NULL REFERENCES auth.users(id),
  content text NOT NULL,
  submitted_at timestamptz DEFAULT now(),
  score integer,
  feedback text,
  CONSTRAINT valid_submission_score CHECK (score IS NULL OR (score >= 0 AND score <= (SELECT max_score FROM assignments WHERE id = assignment_id)))
);

-- Enable RLS
ALTER TABLE assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;

-- Policies for assignments
CREATE POLICY "Teachers can create assignments"
  ON assignments
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = teacher_id);

CREATE POLICY "Teachers can update their own assignments"
  ON assignments
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = teacher_id)
  WITH CHECK (auth.uid() = teacher_id);

CREATE POLICY "Everyone can view assignments"
  ON assignments
  FOR SELECT
  TO authenticated
  USING (true);

-- Policies for submissions
CREATE POLICY "Students can create submissions"
  ON submissions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = student_id);

CREATE POLICY "Students can view their own submissions"
  ON submissions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = student_id OR 
        auth.uid() = (SELECT teacher_id FROM assignments WHERE id = assignment_id));

CREATE POLICY "Teachers can update submissions for their assignments"
  ON submissions
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = (SELECT teacher_id FROM assignments WHERE id = assignment_id))
  WITH CHECK (auth.uid() = (SELECT teacher_id FROM assignments WHERE id = assignment_id));