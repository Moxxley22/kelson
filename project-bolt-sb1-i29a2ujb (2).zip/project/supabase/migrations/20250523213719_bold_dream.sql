/*
  # Create notes table for class materials

  1. New Tables
    - `notes`
      - `id` (uuid, primary key)
      - `title` (text)
      - `content` (text)
      - `class_id` (text)
      - `teacher_id` (uuid, references auth.users)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for teachers to manage notes
    - Add policies for students to view notes
*/

CREATE TABLE notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  class_id text NOT NULL,
  teacher_id uuid NOT NULL REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE notes ENABLE ROW LEVEL SECURITY;

-- Policies for notes
CREATE POLICY "Teachers can create notes"
  ON notes
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = teacher_id);

CREATE POLICY "Teachers can update their own notes"
  ON notes
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = teacher_id)
  WITH CHECK (auth.uid() = teacher_id);

CREATE POLICY "Everyone can view notes"
  ON notes
  FOR SELECT
  TO authenticated
  USING (true);