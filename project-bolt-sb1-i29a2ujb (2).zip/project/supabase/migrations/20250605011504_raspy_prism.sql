/*
  # Create user_ids table for ID management

  1. New Tables
    - `user_ids`
      - `id` (uuid, primary key)
      - `user_id` (text, unique)
      - `role` (text)
      - `assigned` (boolean)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for admin access
*/

CREATE TABLE user_ids (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text UNIQUE NOT NULL,
  role text NOT NULL CHECK (role IN ('student', 'staff')),
  assigned boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE user_ids ENABLE ROW LEVEL SECURITY;

-- Policies for user_ids
CREATE POLICY "Admins can manage user_ids"
  ON user_ids
  FOR ALL
  TO authenticated
  USING (auth.uid() IN (
    SELECT id FROM auth.users WHERE email LIKE '%@admin.kelson.edu'
  ))
  WITH CHECK (auth.uid() IN (
    SELECT id FROM auth.users WHERE email LIKE '%@admin.kelson.edu'
  ));