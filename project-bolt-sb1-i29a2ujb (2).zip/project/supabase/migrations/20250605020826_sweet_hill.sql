/*
  # Add initial admin user

  1. Changes
    - Insert initial admin user
    - Set up admin role and permissions
*/

-- Create initial admin user
INSERT INTO auth.users (
  instance_id,
  id,
  aud,
  role,
  email,
  encrypted_password,
  email_confirmed_at,
  created_at,
  updated_at
) VALUES (
  '00000000-0000-0000-0000-000000000000',
  gen_random_uuid(),
  'authenticated',
  'authenticated',
  'admin@admin.kelson.edu',
  crypt('admin', gen_salt('bf')),
  now(),
  now(),
  now()
);

-- Insert admin ID
INSERT INTO user_ids (user_id, role, assigned)
VALUES ('T00000', 'staff', true);