/*
  # Create passkey authentication tables

  1. New Tables
    - `credentials`
      - `id` (uuid, primary key)
      - `user_id` (text)
      - `role` (text)
      - `credential_id` (text, unique)
      - `public_key` (text)
      - `counter` (integer)
      - `created_at` (timestamptz)
    
    - `registration_challenges`
      - `id` (uuid, primary key)
      - `user_id` (text)
      - `role` (text)
      - `challenge` (text)
      - `expires` (timestamptz)
      - `created_at` (timestamptz)
    
    - `authentication_challenges`
      - `id` (uuid, primary key)
      - `challenge` (text)
      - `expires` (timestamptz)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create credentials table
CREATE TABLE IF NOT EXISTS credentials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  role text NOT NULL CHECK (role IN ('student', 'staff')),
  credential_id text UNIQUE NOT NULL,
  public_key text NOT NULL,
  counter integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create registration challenges table
CREATE TABLE IF NOT EXISTS registration_challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  role text NOT NULL CHECK (role IN ('student', 'staff')),
  challenge text NOT NULL,
  expires timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create authentication challenges table
CREATE TABLE IF NOT EXISTS authentication_challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  challenge text NOT NULL,
  expires timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE credentials ENABLE ROW LEVEL SECURITY;
ALTER TABLE registration_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE authentication_challenges ENABLE ROW LEVEL SECURITY;

-- Policies for credentials
CREATE POLICY "Users can view their own credentials"
  ON credentials
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "System can manage credentials"
  ON credentials
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Policies for registration challenges
CREATE POLICY "System can manage registration challenges"
  ON registration_challenges
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Policies for authentication challenges
CREATE POLICY "System can manage authentication challenges"
  ON authentication_challenges
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);