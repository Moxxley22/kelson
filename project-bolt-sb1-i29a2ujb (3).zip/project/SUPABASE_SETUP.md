# Supabase Database Setup Guide

## Step-by-Step Instructions

### 1. Go to your Supabase Dashboard
- Open your Supabase project dashboard
- Navigate to **SQL Editor** in the left sidebar

### 2. Run Each Migration (Copy the SQL content, not the filename!)

#### Migration 1: Create assignments and submissions tables
Copy and paste this SQL into the SQL Editor:

```sql
/*
  # Create assignments and submissions tables

  1. New Tables
    - `assignments`
      - `id` (uuid, primary key)
      - `title` (text)
      - `description` (text)
      - `due_date` (timestamptz)
      - `teacher_id` (uuid, references auth.users)
      - `created_at` (timestamptz)
      - `class_id` (text)
      - `max_score` (integer)
    
    - `submissions`
      - `id` (uuid, primary key)
      - `assignment_id` (uuid, references assignments)
      - `student_id` (uuid, references auth.users)
      - `content` (text)
      - `submitted_at` (timestamptz)
      - `score` (integer)
      - `feedback` (text)

  2. Security
    - Enable RLS on both tables
    - Add policies for teachers and students
*/

-- Create assignments table
CREATE TABLE assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  due_date timestamptz NOT NULL,
  teacher_id uuid NOT NULL REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  class_id text NOT NULL,
  max_score integer NOT NULL DEFAULT 100,
  CONSTRAINT valid_score CHECK (max_score > 0)
);

-- Create submissions table
CREATE TABLE submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assignment_id uuid NOT NULL REFERENCES assignments(id) ON DELETE CASCADE,
  student_id uuid NOT NULL REFERENCES auth.users(id),
  content text NOT NULL,
  submitted_at timestamptz DEFAULT now(),
  score integer,
  feedback text,
  CONSTRAINT valid_submission_score CHECK (score IS NULL OR (score >= 0 AND score <= (SELECT max_score FROM assignments WHERE id = assignment_id)))
);

-- Enable RLS
ALTER TABLE assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;

-- Policies for assignments
CREATE POLICY "Teachers can create assignments"
  ON assignments
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = teacher_id);

CREATE POLICY "Teachers can update their own assignments"
  ON assignments
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = teacher_id)
  WITH CHECK (auth.uid() = teacher_id);

CREATE POLICY "Everyone can view assignments"
  ON assignments
  FOR SELECT
  TO authenticated
  USING (true);

-- Policies for submissions
CREATE POLICY "Students can create submissions"
  ON submissions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = student_id);

CREATE POLICY "Students can view their own submissions"
  ON submissions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = student_id OR 
        auth.uid() = (SELECT teacher_id FROM assignments WHERE id = assignment_id));

CREATE POLICY "Teachers can update submissions for their assignments"
  ON submissions
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = (SELECT teacher_id FROM assignments WHERE id = assignment_id))
  WITH CHECK (auth.uid() = (SELECT teacher_id FROM assignments WHERE id = assignment_id));
```

#### Migration 2: Create notes table
Copy and paste this SQL:

```sql
/*
  # Create notes table for class materials

  1. New Tables
    - `notes`
      - `id` (uuid, primary key)
      - `title` (text)
      - `content` (text)
      - `class_id` (text)
      - `teacher_id` (uuid, references auth.users)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for teachers to manage notes
    - Add policies for students to view notes
*/

CREATE TABLE notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  class_id text NOT NULL,
  teacher_id uuid NOT NULL REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE notes ENABLE ROW LEVEL SECURITY;

-- Policies for notes
CREATE POLICY "Teachers can create notes"
  ON notes
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = teacher_id);

CREATE POLICY "Teachers can update their own notes"
  ON notes
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = teacher_id)
  WITH CHECK (auth.uid() = teacher_id);

CREATE POLICY "Everyone can view notes"
  ON notes
  FOR SELECT
  TO authenticated
  USING (true);
```

#### Migration 3: Create user_ids table
Copy and paste this SQL:

```sql
/*
  # Create user_ids table for ID management

  1. New Tables
    - `user_ids`
      - `id` (uuid, primary key)
      - `user_id` (text, unique)
      - `role` (text)
      - `assigned` (boolean)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for admin access
*/

CREATE TABLE user_ids (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text UNIQUE NOT NULL,
  role text NOT NULL CHECK (role IN ('student', 'staff')),
  assigned boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE user_ids ENABLE ROW LEVEL SECURITY;

-- Policies for user_ids
CREATE POLICY "Admins can manage user_ids"
  ON user_ids
  FOR ALL
  TO authenticated
  USING (auth.uid() IN (
    SELECT id FROM auth.users WHERE email LIKE '%@admin.kelson.edu'
  ))
  WITH CHECK (auth.uid() IN (
    SELECT id FROM auth.users WHERE email LIKE '%@admin.kelson.edu'
  ));
```

#### Migration 4: Add initial admin user
**SKIP THIS ONE** - We don't need this for manual setup.

#### Migration 5: Create passkey authentication tables
Copy and paste this SQL:

```sql
/*
  # Create passkey authentication tables

  1. New Tables
    - `credentials`
      - `id` (uuid, primary key)
      - `user_id` (text)
      - `role` (text)
      - `credential_id` (text, unique)
      - `public_key` (text)
      - `counter` (integer)
      - `created_at` (timestamptz)
    
    - `registration_challenges`
      - `id` (uuid, primary key)
      - `user_id` (text)
      - `role` (text)
      - `challenge` (text)
      - `expires` (timestamptz)
      - `created_at` (timestamptz)
    
    - `authentication_challenges`
      - `id` (uuid, primary key)
      - `challenge` (text)
      - `expires` (timestamptz)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create credentials table
CREATE TABLE IF NOT EXISTS credentials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  role text NOT NULL CHECK (role IN ('student', 'staff')),
  credential_id text UNIQUE NOT NULL,
  public_key text NOT NULL,
  counter integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create registration challenges table
CREATE TABLE IF NOT EXISTS registration_challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  role text NOT NULL CHECK (role IN ('student', 'staff')),
  challenge text NOT NULL,
  expires timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create authentication challenges table
CREATE TABLE IF NOT EXISTS authentication_challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  challenge text NOT NULL,
  expires timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE credentials ENABLE ROW LEVEL SECURITY;
ALTER TABLE registration_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE authentication_challenges ENABLE ROW LEVEL SECURITY;

-- Policies for credentials
CREATE POLICY "Users can view their own credentials"
  ON credentials
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "System can manage credentials"
  ON credentials
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Policies for registration challenges
CREATE POLICY "System can manage registration challenges"
  ON registration_challenges
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Policies for authentication challenges
CREATE POLICY "System can manage authentication challenges"
  ON authentication_challenges
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);
```

### 3. Verify Setup
After running all migrations, you should see these tables in your Supabase dashboard:
- assignments
- submissions  
- notes
- user_ids
- credentials
- registration_challenges
- authentication_challenges

### 4. Test the Application
Now you can test the passkey registration and login with:
- Student ID: S12345
- Staff ID: T12345

## Important Notes:
- Run each SQL block separately in the SQL Editor
- Click "Run" after pasting each block
- Make sure each migration completes successfully before moving to the next
- Don't run the filename - copy the SQL content inside the files!