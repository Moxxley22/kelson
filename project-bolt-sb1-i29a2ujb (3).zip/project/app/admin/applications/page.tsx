"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, Clock, CircleCheck as CheckCircle, CircleAlert as AlertCircle, Download, Eye, X } from "lucide-react";

interface Application {
  id: string;
  submittedAt: string;
  status: string;
  data: {
    firstName: string;
    lastName: string;
    gradeApplying: string;
    parentEmail: string;
    parentPhone: string;
    dateOfBirth?: string;
    gender?: string;
    nationality?: string;
    email?: string;
    phone?: string;
    address?: string;
    city?: string;
    state?: string;
    zipCode?: string;
    country?: string;
  };
}

interface Dashboard {
  totalApplications: number;
  pendingApplications: number;
  recentApplications: Application[];
}

export default function AdminApplicationsPage() {
  const [dashboard, setDashboard] = useState<Dashboard | null>(null);
  const [applications, setApplications] = useState<Application[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedApplication, setSelectedApplication] = useState<Application | null>(null);

  useEffect(() => {
    fetchDashboard();
    fetchApplications();
  }, []);

  const fetchDashboard = async () => {
    try {
      const response = await fetch('/api/admin/applications/dashboard');
      if (response.ok) {
        const data = await response.json();
        setDashboard(data);
      }
    } catch (error) {
      console.error('Failed to fetch dashboard:', error);
    }
  };

  const fetchApplications = async () => {
    try {
      const response = await fetch('/api/admin/applications');
      if (response.ok) {
        const data = await response.json();
        setApplications(data.applications || []);
      }
    } catch (error) {
      console.error('Failed to fetch applications:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const updateApplicationStatus = async (applicationId: string, newStatus: string) => {
    try {
      const response = await fetch('/api/admin/applications/update-status', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ applicationId, status: newStatus }),
      });

      if (response.ok) {
        fetchDashboard();
        fetchApplications();
      }
    } catch (error) {
      console.error('Failed to update application status:', error);
    }
  };

  const exportApplications = async () => {
    try {
      const response = await fetch('/api/admin/applications/export');
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `applications-${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }
    } catch (error) {
      console.error('Failed to export applications:', error);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
      case 'approved':
        return <Badge variant="secondary" className="bg-green-100 text-green-800"><CheckCircle className="h-3 w-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="secondary" className="bg-red-100 text-red-800"><AlertCircle className="h-3 w-3 mr-1" />Rejected</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  if (isLoading) {
    return (
      <main className="container mx-auto px-4 py-8">
        <div className="text-center">Loading applications...</div>
      </main>
    );
  }

  return (
    <main className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold tracking-tight">Applications Dashboard</h1>
          <p className="text-muted-foreground">Manage and review student applications</p>
        </div>
        <Button onClick={exportApplications} className="flex items-center gap-2">
          <Download className="h-4 w-4" />
          Export CSV
        </Button>
      </div>

      {dashboard && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Applications</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{dashboard.totalApplications}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Review</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{dashboard.pendingApplications}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">This Week</CardTitle>
              <CheckCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {applications.filter(app => {
                  const weekAgo = new Date();
                  weekAgo.setDate(weekAgo.getDate() - 7);
                  return new Date(app.submittedAt) > weekAgo;
                }).length}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <Tabs defaultValue="all" className="w-full">
        <TabsList>
          <TabsTrigger value="all">All Applications</TabsTrigger>
          <TabsTrigger value="pending">Pending</TabsTrigger>
          <TabsTrigger value="approved">Approved</TabsTrigger>
          <TabsTrigger value="rejected">Rejected</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <ApplicationsList 
            applications={applications} 
            onStatusUpdate={updateApplicationStatus}
            onViewDetails={setSelectedApplication}
          />
        </TabsContent>

        <TabsContent value="pending">
          <ApplicationsList 
            applications={applications.filter(app => app.status === 'pending')} 
            onStatusUpdate={updateApplicationStatus}
            onViewDetails={setSelectedApplication}
          />
        </TabsContent>

        <TabsContent value="approved">
          <ApplicationsList 
            applications={applications.filter(app => app.status === 'approved')} 
            onStatusUpdate={updateApplicationStatus}
            onViewDetails={setSelectedApplication}
          />
        </TabsContent>

        <TabsContent value="rejected">
          <ApplicationsList 
            applications={applications.filter(app => app.status === 'rejected')} 
            onStatusUpdate={updateApplicationStatus}
            onViewDetails={setSelectedApplication}
          />
        </TabsContent>
      </Tabs>

      {selectedApplication && (
        <ApplicationDetailsModal 
          application={selectedApplication}
          onClose={() => setSelectedApplication(null)}
          onStatusUpdate={updateApplicationStatus}
        />
      )}
    </main>
  );
}

function ApplicationsList({ 
  applications, 
  onStatusUpdate, 
  onViewDetails 
}: { 
  applications: Application[];
  onStatusUpdate: (id: string, status: string) => void;
  onViewDetails: (app: Application) => void;
}) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
      case 'approved':
        return <Badge variant="secondary" className="bg-green-100 text-green-800"><CheckCircle className="h-3 w-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="secondary" className="bg-red-100 text-red-800"><AlertCircle className="h-3 w-3 mr-1" />Rejected</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Applications ({applications.length})</CardTitle>
        <CardDescription>Review and manage student applications</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {applications.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">No applications found.</p>
          ) : (
            applications.map((app) => (
              <div key={app.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-4">
                    <div>
                      <h4 className="font-medium">{app.data.firstName} {app.data.lastName}</h4>
                      <p className="text-sm text-muted-foreground">Grade {app.data.gradeApplying}</p>
                    </div>
                    <div>
                      <p className="text-sm">{app.data.parentEmail}</p>
                      <p className="text-sm text-muted-foreground">{new Date(app.submittedAt).toLocaleDateString()}</p>
                    </div>
                    {getStatusBadge(app.status)}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => onViewDetails(app)}>
                    <Eye className="h-4 w-4 mr-1" />
                    View
                  </Button>
                  {app.status === 'pending' && (
                    <>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => onStatusUpdate(app.id, 'approved')}
                        className="text-green-600 hover:text-green-700"
                      >
                        Approve
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => onStatusUpdate(app.id, 'rejected')}
                        className="text-red-600 hover:text-red-700"
                      >
                        Reject
                      </Button>
                    </>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function ApplicationDetailsModal({ 
  application, 
  onClose, 
  onStatusUpdate 
}: { 
  application: Application;
  onClose: () => void;
  onStatusUpdate: (id: string, status: string) => void;
}) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50" onClick={onClose}>
      <div className="bg-white dark:bg-gray-900 rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold">Complete Application Details</h2>
            <Button variant="outline" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="space-y-6">
            {/* Student Information */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Student Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Full Name</label>
                    <p className="text-base">{application.data.firstName} {application.data.lastName}</p>
                  </div>
                  {application.data.dateOfBirth && (
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Date of Birth</label>
                      <p className="text-base">{new Date(application.data.dateOfBirth).toLocaleDateString()}</p>
                    </div>
                  )}
                  {application.data.gender && (
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Gender</label>
                      <p className="text-base capitalize">{application.data.gender}</p>
                    </div>
                  )}
                  {application.data.nationality && (
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Nationality</label>
                      <p className="text-base">{application.data.nationality}</p>
                    </div>
                  )}
                  {application.data.email && (
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Student Email</label>
                      <p className="text-base">{application.data.email}</p>
                    </div>
                  )}
                  {application.data.phone && (
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Student Phone</label>
                      <p className="text-base">{application.data.phone}</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Contact Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {application.data.address && (
                    <div className="md:col-span-2">
                      <label className="text-sm font-medium text-muted-foreground">Address</label>
                      <p className="text-base">{application.data.address}</p>
                    </div>
                  )}
                  {application.data.city && (
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">City</label>
                      <p className="text-base">{application.data.city}</p>
                    </div>
                  )}
                  {application.data.state && (
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">State/Province</label>
                      <p className="text-base">{application.data.state}</p>
                    </div>
                  )}
                  {application.data.zipCode && (
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">ZIP/Postal Code</label>
                      <p className="text-base">{application.data.zipCode}</p>
                    </div>
                  )}
                  {application.data.country && (
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Country</label>
                      <p className="text-base">{application.data.country}</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
            
          <div className="flex gap-2 pt-4">
            {application.status === 'pending' && (
              <>
                <Button 
                  onClick={() => {
                    onStatusUpdate(application.id, 'approved');
                    onClose();
                  }}
                  className="bg-green-600 hover:bg-green-700"
                >
                  Approve Application
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => {
                    onStatusUpdate(application.id, 'rejected');
                    onClose();
                  }}
                  className="text-red-600 hover:text-red-700"
                >
                  Reject Application
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}