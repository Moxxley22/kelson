import { NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';

export async function GET() {
  try {
    const dashboardPath = path.join(process.cwd(), 'applications', 'dashboard.json');
    
    try {
      const content = await fs.readFile(dashboardPath, 'utf-8');
      const dashboard = JSON.parse(content);
      return NextResponse.json(dashboard);
    } catch (error) {
      // Return default dashboard if file doesn't exist
      return NextResponse.json({
        totalApplications: 0,
        pendingApplications: 0,
        recentApplications: []
      });
    }
  } catch (error) {
    console.error('Error reading dashboard:', error);
    return NextResponse.json(
      { error: 'Failed to load dashboard' },
      { status: 500 }
    );
  }
}