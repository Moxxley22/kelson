import { NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';

export async function POST(request: Request) {
  try {
    const { applicationId, status } = await request.json();
    
    if (!applicationId || !status) {
      return NextResponse.json(
        { error: 'Application ID and status are required' },
        { status: 400 }
      );
    }
    
    const applicationsDir = path.join(process.cwd(), 'applications');
    const files = await fs.readdir(applicationsDir);
    const applicationFile = files.find(file => file.startsWith(applicationId));
    
    if (!applicationFile) {
      return NextResponse.json(
        { error: 'Application not found' },
        { status: 404 }
      );
    }
    
    const filePath = path.join(applicationsDir, applicationFile);
    const content = await fs.readFile(filePath, 'utf-8');
    const application = JSON.parse(content);
    
    // Update status
    const oldStatus = application.status;
    application.status = status;
    application.updatedAt = new Date().toISOString();
    
    // Save updated application
    await fs.writeFile(filePath, JSON.stringify(application, null, 2));
    
    // Update dashboard
    await updateDashboardCounts(oldStatus, status);
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error updating application status:', error);
    return NextResponse.json(
      { error: 'Failed to update application status' },
      { status: 500 }
    );
  }
}

async function updateDashboardCounts(oldStatus: string, newStatus: string) {
  try {
    const dashboardPath = path.join(process.cwd(), 'applications', 'dashboard.json');
    
    let dashboard = {
      totalApplications: 0,
      pendingApplications: 0,
      recentApplications: []
    };
    
    try {
      const content = await fs.readFile(dashboardPath, 'utf-8');
      dashboard = JSON.parse(content);
    } catch {
      // File doesn't exist, use default
    }
    
    // Update counts
    if (oldStatus === 'pending' && newStatus !== 'pending') {
      dashboard.pendingApplications = Math.max(0, dashboard.pendingApplications - 1);
    } else if (oldStatus !== 'pending' && newStatus === 'pending') {
      dashboard.pendingApplications += 1;
    }
    
    await fs.writeFile(dashboardPath, JSON.stringify(dashboard, null, 2));
  } catch (error) {
    console.error('Error updating dashboard counts:', error);
  }
}