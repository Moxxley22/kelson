import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search');

    if (!search) {
      return NextResponse.json(
        { error: 'Search term is required' },
        { status: 400 }
      );
    }

    const applicationsDir = path.join(process.cwd(), 'applications');
    
    try {
      const files = await fs.readdir(applicationsDir);
      const jsonFiles = files.filter(file => file.endsWith('.json') && file !== 'dashboard.json');

      for (const file of jsonFiles) {
        const filePath = path.join(applicationsDir, file);
        const content = await fs.readFile(filePath, 'utf-8');
        const application = JSON.parse(content);

        // Search by email or student name
        const searchLower = search.toLowerCase();
        const studentName = `${application.data.firstName} ${application.data.lastName}`.toLowerCase();
        const parentEmail = application.data.parentEmail?.toLowerCase() || '';
        const studentEmail = application.data.email?.toLowerCase() || '';

        if (
          studentName.includes(searchLower) ||
          parentEmail.includes(searchLower) ||
          studentEmail.includes(searchLower)
        ) {
          return NextResponse.json({ application });
        }
      }

      return NextResponse.json(
        { error: 'Application not found' },
        { status: 404 }
      );

    } catch (error) {
      console.error('Error reading applications directory:', error);
      return NextResponse.json(
        { error: 'Unable to search applications' },
        { status: 500 }
      );
    }

  } catch (error) {
    console.error('Error in application status API:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}