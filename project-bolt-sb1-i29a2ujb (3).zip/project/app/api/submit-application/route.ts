import { NextResponse } from "next/server";
import nodemailer from "nodemailer";
import fs from 'fs/promises';
import path from 'path';

export async function POST(req: Request) {
  try {
    console.log("🚀 POST REQUEST RECEIVED - Starting application processing");
    const formData = await req.formData();

    // Extract fields (strings and booleans)
    const data: Record<string, any> = {};
    formData.forEach((value, key) => {
      if (value instanceof File) return; // skipping files for now
      data[key] = value;
    });

    console.log("📋 FORM DATA EXTRACTED:", {
      firstName: data.firstName,
      lastName: data.lastName,
      parentEmail: data.parentEmail,
      gradeApplying: data.gradeApplying
    });

    console.log("🔧 EMAIL CONFIGURATION DEBUG");
    console.log("EMAIL_USER exists:", !!process.env.EMAIL_USER);
    console.log("EMAIL_USER value:", process.env.EMAIL_USER ? `${process.env.EMAIL_USER.substring(0, 3)}***@${process.env.EMAIL_USER.split('@')[1]}` : 'NOT SET');
    console.log("EMAIL_PASS exists:", !!process.env.EMAIL_PASS);
    console.log("EMAIL_PASS length:", process.env.EMAIL_PASS ? process.env.EMAIL_PASS.length : 0);

    // Save application to file system as backup
    await saveApplicationToFile(data);
    
    // Generate application summary for admin dashboard
    await updateApplicationsDashboard(data);

    // Check if email credentials are configured
    if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
      console.log("❌ EMAIL CREDENTIALS NOT CONFIGURED");
      console.log("📝 Application will be logged to console instead of emailed:");
      console.log("📝 Application logged to console:");
      console.log(`Student: ${data.firstName} ${data.lastName}`);
      console.log(`Grade: ${data.gradeApplying}`);
      console.log(`Parent Email: ${data.parentEmail}`);
      
      return NextResponse.json({ 
        success: true, 
        message: "Application received successfully! Your application has been saved and our admissions team will contact you within 2-3 business days. You can also check your application status at /applications/status." 
      });
    }

    console.log("✅ EMAIL CREDENTIALS FOUND - Proceeding with email setup");
    console.log("📧 ATTEMPTING EMAIL SETUP");

    // Test network connectivity with very short timeout
    try {
      console.log("🔍 Testing SMTP connectivity with short timeout...");
      const quickTestTransporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false,
        requireTLS: true,
        connectionTimeout: 5000, // Very short timeout for quick test
        greetingTimeout: 3000,
        socketTimeout: 5000,
        auth: {
          user: process.env.EMAIL_USER,
          pass: process.env.EMAIL_PASS,
        },
      });

      await quickTestTransporter.verify();
      console.log("✅ Quick SMTP connectivity test passed");
      
    } catch (quickTestError) {
      console.log("⚠️ SMTP CONNECTIVITY ISSUE DETECTED (Quick Test):");
      console.log("Network cannot reach Gmail SMTP server - this is expected in restricted environments");
      console.log("📝 Falling back to console logging for application processing");
      
      // Log application data for manual processing
      console.log("=".repeat(50));
      console.log("📋 NEW APPLICATION RECEIVED (Network Fallback)");
      console.log("=".repeat(50));
      console.log(`Student: ${data.firstName} ${data.lastName}`);
      console.log(`Grade: ${data.gradeApplying}`);
      console.log(`Parent Email: ${data.parentEmail}`);
      console.log(`Parent Phone: ${data.parentPhone}`);
      console.log(`Submitted: ${new Date().toISOString()}`);
      console.log("=".repeat(50));
      
      return NextResponse.json({ 
        success: true, 
        message: "Application received successfully! Your application has been saved and our admissions team will contact you within 2-3 business days. You can also check your application status at /applications/status." 
      });
    }

    // Define the email message template
    const message = `
New Application Received:

STUDENT INFORMATION:
Name: ${data.firstName} ${data.lastName}
Date of Birth: ${data.dateOfBirth}
Gender: ${data.gender}
Nationality: ${data.nationality}
Grade Applying: ${data.gradeApplying}

CONTACT INFORMATION:
Email: ${data.email}
Phone: ${data.phone}
Address: ${data.address}, ${data.city}, ${data.state} ${data.zipCode}, ${data.country}

ACADEMIC INFORMATION:
Current School: ${data.currentSchool || "N/A"}
Previous GPA: ${data.previousGPA || "N/A"}

PARENT/GUARDIAN INFORMATION:
Name: ${data.parentFirstName} ${data.parentLastName}
Email: ${data.parentEmail}
Phone: ${data.parentPhone}
Relationship: ${data.relationship}

ADDITIONAL INFORMATION:
Extracurricular Activities:
${data.extracurriculars || "N/A"}

Personal Statement:
${data.personalStatement || "N/A"}

Special Needs/Accommodations:
${data.specialNeeds || "N/A"}

---
This application was submitted through the Kelson International School website.
Please review and contact the family within 5-7 business days.
    `;

    console.log("📝 EMAIL MESSAGE PREPARED (length:", message.length, "characters)");

    // Setup main transporter with longer timeouts for actual sending
    try {
      console.log("🔧 Setting up main email transporter...");
      const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false,
        requireTLS: true,
        connectionTimeout: 60000,
        greetingTimeout: 30000,
        socketTimeout: 60000,
        auth: {
          user: process.env.EMAIL_USER,
          pass: process.env.EMAIL_PASS,
        },
      });

      console.log("📤 SENDING EMAIL");

      // Send to admissions team
      await transporter.sendMail({
        from: process.env.EMAIL_USER,
        to: "officialkelsonschool@gmail.com, kelechukwuapugo@gmail.com",
        subject: `New Application - ${data.firstName} ${data.lastName} (Grade ${data.gradeApplying})`,
        text: message,
      });

      console.log("✅ Application email sent successfully");

      // Send confirmation email to parent
      console.log("📤 SENDING CONFIRMATION EMAIL TO PARENT");
      await transporter.sendMail({
        from: process.env.EMAIL_USER,
        to: data.parentEmail,
        subject: "Application Received - Kelson International School",
        text: `
Dear ${data.parentFirstName} ${data.parentLastName},

Thank you for submitting an application for ${data.firstName} ${data.lastName} to Kelson International School.

We have received your application for Grade ${data.gradeApplying} and will review it carefully. Our admissions team will contact you within 5-7 business days to discuss next steps.

If you have any questions in the meantime, please don't hesitate to contact us.

Best regards,
Kelson International School Admissions Team
Email: officialkelsonschool@gmail.com
Phone: (123) 456-7890

---
This is an automated confirmation email.
        `,
      });

      console.log("✅ Confirmation email sent successfully");

      return NextResponse.json({ 
        success: true, 
        message: "Application submitted successfully! Check your email for confirmation." 
      });

    } catch (connectivityError) {
      console.log("⚠️ EMAIL SENDING FAILED:");
      console.log("Error type:", connectivityError.constructor.name);
      console.log("Error message:", connectivityError.message);
      console.log("Error code:", connectivityError.code);
      console.log("📝 This is likely due to network restrictions preventing SMTP access");
      
      // Log application data for manual processing
      console.log("=".repeat(50));
      console.log("📋 NEW APPLICATION RECEIVED (Email Failed)");
      console.log("=".repeat(50));
      console.log(`Student: ${data.firstName} ${data.lastName}`);
      console.log(`Grade: ${data.gradeApplying}`);
      console.log(`Parent Email: ${data.parentEmail}`);
      console.log(`Parent Phone: ${data.parentPhone}`);
      console.log(`Submitted: ${new Date().toISOString()}`);
      console.log("=".repeat(50));
      
      return NextResponse.json({ 
        success: true, 
        message: "Application received successfully! Your application has been saved and our admissions team will contact you within 2-3 business days. You can also check your application status at /applications/status." 
      });
    }

  } catch (err) {
    console.error("❌ UNEXPECTED ERROR IN APPLICATION PROCESSING:");
    console.error("Error type:", err.constructor.name);
    console.error("Error message:", err.message);
    console.error("Full error:", err);
    console.log("📝 Application logged due to email failure:");
    
    // Log basic info if we have it
    try {
      console.log(`Student: ${data.firstName} ${data.lastName}`);
      console.log(`Grade: ${data.gradeApplying}`);
      console.log(`Parent Email: ${data.parentEmail}`);
    } catch {
      console.log("Unable to log application data");
    }
    
    return NextResponse.json({ 
      success: true, 
      message: "Application received successfully! Your application has been saved and our admissions team will contact you within 2-3 business days. You can also check your application status at /applications/status." 
    });
  }
}

// Save application to JSON file for backup and admin review
async function saveApplicationToFile(data: Record<string, any>) {
  try {
    const applicationsDir = path.join(process.cwd(), 'applications');
    
    // Create applications directory if it doesn't exist
    try {
      await fs.access(applicationsDir);
    } catch {
      await fs.mkdir(applicationsDir, { recursive: true });
    }
    
    const applicationId = `APP-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const filename = `${applicationId}.json`;
    const filepath = path.join(applicationsDir, filename);
    
    const applicationData = {
      id: applicationId,
      submittedAt: new Date().toISOString(),
      status: 'pending',
      data: data
    };
    
    await fs.writeFile(filepath, JSON.stringify(applicationData, null, 2));
    console.log(`✅ Application saved to file: ${filename}`);
    
    return applicationId;
  } catch (error) {
    console.error('❌ Failed to save application to file:', error);
  }
}

// Update applications dashboard summary
async function updateApplicationsDashboard(data: Record<string, any>) {
  try {
    const dashboardPath = path.join(process.cwd(), 'applications', 'dashboard.json');
    
    let dashboard = {
      totalApplications: 0,
      pendingApplications: 0,
      recentApplications: []
    };
    
    // Try to read existing dashboard
    try {
      const existing = await fs.readFile(dashboardPath, 'utf-8');
      dashboard = JSON.parse(existing);
    } catch {
      // File doesn't exist, use default
    }
    
    // Update dashboard
    dashboard.totalApplications += 1;
    dashboard.pendingApplications += 1;
    dashboard.recentApplications.unshift({
      name: `${data.firstName} ${data.lastName}`,
      grade: data.gradeApplying,
      email: data.parentEmail,
      submittedAt: new Date().toISOString(),
      status: 'pending'
    });
    
    // Keep only last 10 recent applications
    dashboard.recentApplications = dashboard.recentApplications.slice(0, 10);
    
    await fs.writeFile(dashboardPath, JSON.stringify(dashboard, null, 2));
    console.log('✅ Dashboard updated with new application');
    
  } catch (error) {
    console.error('❌ Failed to update dashboard:', error);
  }
}