import { NextRequest, NextResponse } from 'next/server';
import nodemailer from 'nodemailer';

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json();
    
    if (!email) {
      return NextResponse.json(
        { success: false, message: 'Email address is required' },
        { status: 400 }
      );
    }

    // Check if email credentials are configured
    const emailUser = process.env.EMAIL_USER;
    const emailPass = process.env.EMAIL_PASS;
    
    if (!emailUser || !emailPass) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Email credentials not configured. Please set EMAIL_USER and EMAIL_PASS environment variables.' 
        },
        { status: 500 }
      );
    }

    // Test network connectivity first
    try {
      console.log('🔍 Testing SMTP connectivity...');
      // Create email transporter with very short timeout for quick connectivity test
      const transporter = nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        secure: false,
        requireTLS: true,
        auth: {
          user: emailUser,
          pass: emailPass,
        },
        connectionTimeout: 5000, // Very short timeout for quick test
        greetingTimeout: 3000,
        socketTimeout: 5000,
      });

      // Verify connectivity
      await transporter.verify();
      console.log('✅ SMTP connectivity verified');

      // Send test email
      await transporter.sendMail({
        from: emailUser,
        to: email,
        subject: 'Email Test - Kelson International School',
        text: `
Hello!

This is a test email from Kelson International School's application system.

If you received this email, it means the email configuration is working correctly!

Test Details:
- Sent at: ${new Date().toISOString()}
- From: ${emailUser}
- To: ${email}

Best regards,
Kelson International School System
        `,
      });

      return NextResponse.json({ 
        success: true, 
        message: 'Test email sent successfully!' 
      });

    } catch (connectivityError) {
      console.log('⚠️ SMTP connectivity issue:', connectivityError.message);
      
      return NextResponse.json(
        { 
          success: false, 
          message: `Network connectivity issue: Cannot reach Gmail SMTP server. This is expected in restricted environments like WebContainer. The application form will still work and log submissions to the console. Error: ${connectivityError.message}` 
        },
        { status: 500 }
      );
    }

  } catch (error) {
    console.error('❌ Email test failed:', error);
    return NextResponse.json(
      { 
        success: false, 
        message: `Failed to send test email: ${error instanceof Error ? error.message : 'Unknown error'}` 
      },
      { status: 500 }
    );
  }
}