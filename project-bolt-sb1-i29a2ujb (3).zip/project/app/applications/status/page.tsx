"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Search, CircleCheck as CheckCircle, Clock, CircleAlert as AlertCircle } from "lucide-react";

export default function ApplicationStatusPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [applicationData, setApplicationData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchTerm.trim()) return;

    setIsLoading(true);
    setError("");
    setApplicationData(null);

    try {
      const response = await fetch(`/api/applications/status?search=${encodeURIComponent(searchTerm)}`);
      const data = await response.json();

      if (response.ok && data.application) {
        setApplicationData(data.application);
      } else {
        setError("No application found. Please check your information and try again.");
      }
    } catch (err) {
      setError("Unable to search applications at this time. Please try again later.");
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'approved':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'rejected':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Clock className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending':
        return 'Under Review';
      case 'approved':
        return 'Approved';
      case 'rejected':
        return 'Not Approved';
      default:
        return 'Unknown';
    }
  };

  return (
    <main className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold tracking-tight mb-4">Application Status</h1>
          <p className="text-xl text-muted-foreground">
            Check the status of your application to Kelson International School
          </p>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Search Your Application
            </CardTitle>
            <CardDescription>
              Enter your email address or student name to check application status
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSearch} className="space-y-4">
              <div>
                <Label htmlFor="search">Email Address or Student Name</Label>
                <Input
                  id="search"
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Enter email or student name"
                  required
                />
              </div>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Searching..." : "Check Status"}
              </Button>
            </form>

            {error && (
              <div className="mt-4 p-4 bg-red-50 text-red-800 rounded-lg border border-red-200">
                {error}
              </div>
            )}
          </CardContent>
        </Card>

        {applicationData && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {getStatusIcon(applicationData.status)}
                Application Found
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Student Name</Label>
                  <p className="text-lg font-medium">{applicationData.data.firstName} {applicationData.data.lastName}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Grade Applying</Label>
                  <p className="text-lg font-medium">{applicationData.data.gradeApplying}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Status</Label>
                  <p className={`text-lg font-medium flex items-center gap-2 ${
                    applicationData.status === 'approved' ? 'text-green-600' :
                    applicationData.status === 'rejected' ? 'text-red-600' :
                    'text-yellow-600'
                  }`}>
                    {getStatusIcon(applicationData.status)}
                    {getStatusText(applicationData.status)}
                  </p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Submitted</Label>
                  <p className="text-lg font-medium">
                    {new Date(applicationData.submittedAt).toLocaleDateString()}
                  </p>
                </div>
              </div>

              <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                <h4 className="font-medium text-blue-900 mb-2">Next Steps</h4>
                <p className="text-blue-800 text-sm">
                  {applicationData.status === 'pending' && 
                    "Your application is currently under review. Our admissions team will contact you within 2-3 business days with updates."
                  }
                  {applicationData.status === 'approved' && 
                    "Congratulations! Your application has been approved. You should receive enrollment information via email soon."
                  }
                  {applicationData.status === 'rejected' && 
                    "Thank you for your interest. While we cannot offer admission at this time, we encourage you to apply again in the future."
                  }
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="mt-8 text-center">
          <p className="text-muted-foreground mb-4">
            Need help or have questions about your application?
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="outline" asChild>
              <a href="/contact">Contact Admissions</a>
            </Button>
            <Button variant="outline" asChild>
              <a href="tel:+1234567890">Call (123) 456-7890</a>
            </Button>
          </div>
        </div>
      </div>
    </main>
  );
}