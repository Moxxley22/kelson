"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Calendar, User, GraduationCap, FileText, Phone, Mail, MapPin } from "lucide-react";
import { toast } from "sonner";

export default function ApplicationPage() {
  const [formData, setFormData] = useState({
    // Student Information
    firstName: "",
    lastName: "",
    dateOfBirth: "",
    gender: "",
    nationality: "",
    
    // Contact Information
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    country: "",
    
    // Academic Information
    gradeApplying: "",
    currentSchool: "",
    previousGPA: "",
    
    // Parent/Guardian Information
    parentFirstName: "",
    parentLastName: "",
    parentEmail: "",
    parentPhone: "",
    relationship: "",
    
    // Additional Information
    extracurriculars: "",
    personalStatement: "",
    specialNeeds: "",
    
    // Agreements
    agreeToTerms: false,
    agreeToContact: false,
    
    // Documents
    birthCertificate: null as File | null,
    immunizationRecords: null as File | null,
    academicRecords: null as File | null,
    teacherRecommendations: null as File | null,
    healthRecords: null as File | null,
    passportCopy: null as File | null,
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log("🚀 FORM SUBMISSION STARTED");
    setIsSubmitting(true);

    try {
      console.log("📦 Creating FormData...");
      // Create FormData to handle file uploads
      const submitData = new FormData();
      
      // Add all form fields
      Object.entries(formData).forEach(([key, value]) => {
        if (value instanceof File) {
          submitData.append(key, value);
        } else if (typeof value === 'boolean') {
          submitData.append(key, value.toString());
        } else if (value !== null && value !== '') {
          submitData.append(key, value as string);
        }
      });

      console.log("🌐 Sending request to /api/submit-application...");
      // Send to our API endpoint
      const response = await fetch('/api/submit-application', {
        method: 'POST',
        body: submitData,
      });

      console.log("📨 Response received:", response.status, response.statusText);
      
      if (response.ok) {
        const responseData = await response.json();
        console.log("✅ SUCCESS Response:", responseData);
        toast.success("Application submitted successfully! We will contact you within 5-7 business days.");
        // Reset form
        setFormData({
          firstName: "",
          lastName: "",
          dateOfBirth: "",
          gender: "",
          nationality: "",
          email: "",
          phone: "",
          address: "",
          city: "",
          state: "",
          zipCode: "",
          country: "",
          gradeApplying: "",
          currentSchool: "",
          previousGPA: "",
          parentFirstName: "",
          parentLastName: "",
          parentEmail: "",
          parentPhone: "",
          relationship: "",
          extracurriculars: "",
          personalStatement: "",
          specialNeeds: "",
          agreeToTerms: false,
          agreeToContact: false,
          birthCertificate: null,
          immunizationRecords: null,
          academicRecords: null,
          teacherRecommendations: null,
          healthRecords: null,
          passportCopy: null,
        });
      } else {
        const errorData = await response.text();
        console.log("❌ ERROR Response:", errorData);
        throw new Error('Failed to submit application');
      }
    } catch (error) {
      console.error('❌ FORM SUBMISSION ERROR:', error);
      toast.error("Failed to submit application. Please try again or contact us directly.");
    } finally {
      console.log("🏁 FORM SUBMISSION COMPLETED");
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleFileChange = (field: string, file: File | null) => {
    setFormData(prev => ({
      ...prev,
      [field]: file
    }));
  };

  const getRequiredDocuments = () => {
    const grade = formData.gradeApplying;
    if (grade === 'kindergarten' || grade === 'grade-1' || grade === 'grade-2') {
      return ['birthCertificate', 'immunizationRecords'];
    } else if (grade === 'grade-3' || grade === 'grade-4' || grade === 'grade-5' || grade === 'grade-6') {
      return ['birthCertificate', 'academicRecords', 'healthRecords'];
    } else {
      return ['academicRecords', 'teacherRecommendations', 'healthRecords', 'passportCopy'];
    }
  };
  return (
    <main className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold tracking-tight mb-4">Apply to Kelson International School</h1>
          <p className="text-xl text-muted-foreground">
            Begin your educational journey with us. Please fill out the application form below.
          </p>
        </div>

        {/* Application Process Steps */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Application Process
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-2">1</div>
                <p className="text-sm font-medium">Submit Application</p>
              </div>
              <div className="text-center">
                <div className="w-8 h-8 bg-gray-200 text-gray-600 rounded-full flex items-center justify-center mx-auto mb-2">2</div>
                <p className="text-sm text-muted-foreground">Document Review</p>
              </div>
              <div className="text-center">
                <div className="w-8 h-8 bg-gray-200 text-gray-600 rounded-full flex items-center justify-center mx-auto mb-2">3</div>
                <p className="text-sm text-muted-foreground">Interview & Assessment</p>
              </div>
              <div className="text-center">
                <div className="w-8 h-8 bg-gray-200 text-gray-600 rounded-full flex items-center justify-center mx-auto mb-2">4</div>
                <p className="text-sm text-muted-foreground">Admission Decision</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Application Form */}
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Student Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Student Information
              </CardTitle>
              <CardDescription>
                Please provide the student's personal information
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name *</Label>
                  <Input
                    id="firstName"
                    value={formData.firstName}
                    onChange={(e) => handleInputChange("firstName", e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name *</Label>
                  <Input
                    id="lastName"
                    value={formData.lastName}
                    onChange={(e) => handleInputChange("lastName", e.target.value)}
                    required
                  />
                </div>
              </div>
              
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="dateOfBirth">Date of Birth *</Label>
                  <Input
                    id="dateOfBirth"
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={(e) => handleInputChange("dateOfBirth", e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label>Gender *</Label>
                  <Select onValueChange={(value) => handleInputChange("gender", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                      <SelectItem value="prefer-not-to-say">Prefer not to say</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="nationality">Nationality *</Label>
                  <Input
                    id="nationality"
                    value={formData.nationality}
                    onChange={(e) => handleInputChange("nationality", e.target.value)}
                    required
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="h-5 w-5" />
                Contact Information
              </CardTitle>
              <CardDescription>
                Student's contact details
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleInputChange("phone", e.target.value)}
                    required
                  />
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="country">Country *</Label>
                  <Input
                    id="country"
                    value={formData.country}
                    onChange={(e) => handleInputChange("country", e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="city">City *</Label>
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) => handleInputChange("city", e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="state">State/Province *</Label>
                  <Input
                    id="state"
                    value={formData.state}
                    onChange={(e) => handleInputChange("state", e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="zipCode">ZIP/Postal Code *</Label>
                  <Input
                    id="zipCode"
                    value={formData.zipCode}
                    onChange={(e) => handleInputChange("zipCode", e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="country">Country *</Label>
                  <Input
                    id="country"
                    value={formData.country}
                    onChange={(e) => handleInputChange("country", e.target.value)}
                    required
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Academic Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="h-5 w-5" />
                Academic Information
              </CardTitle>
              <CardDescription>
                Student's academic background
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>Grade Applying For *</Label>
                  <Select onValueChange={(value) => handleInputChange("gradeApplying", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select grade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="kindergarten">Kindergarten</SelectItem>
                      <SelectItem value="grade-1">Grade 1</SelectItem>
                      <SelectItem value="grade-2">Grade 2</SelectItem>
                      <SelectItem value="grade-3">Grade 3</SelectItem>
                      <SelectItem value="grade-4">Grade 4</SelectItem>
                      <SelectItem value="grade-5">Grade 5</SelectItem>
                      <SelectItem value="grade-6">Grade 6</SelectItem>
                      <SelectItem value="grade-7">Grade 7</SelectItem>
                      <SelectItem value="grade-8">Grade 8</SelectItem>
                      <SelectItem value="grade-9">Grade 9</SelectItem>
                      <SelectItem value="grade-10">Grade 10</SelectItem>
                      <SelectItem value="grade-11">Grade 11</SelectItem>
                      <SelectItem value="grade-12">Grade 12</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="currentSchool">Current/Previous School</Label>
                  <Input
                    id="currentSchool"
                    value={formData.currentSchool}
                    onChange={(e) => handleInputChange("currentSchool", e.target.value)}
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="previousGPA">Previous GPA/Academic Performance (if applicable)</Label>
                <Input
                  id="previousGPA"
                  value={formData.previousGPA}
                  onChange={(e) => handleInputChange("previousGPA", e.target.value)}
                  placeholder="e.g., 3.8/4.0 or A average"
                />
              </div>
            </CardContent>
          </Card>

          {/* Parent/Guardian Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Phone className="h-5 w-5" />
                Parent/Guardian Information
              </CardTitle>
              <CardDescription>
                Primary contact person for the student
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="parentFirstName">First Name *</Label>
                  <Input
                    id="parentFirstName"
                    value={formData.parentFirstName}
                    onChange={(e) => handleInputChange("parentFirstName", e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="parentLastName">Last Name *</Label>
                  <Input
                    id="parentLastName"
                    value={formData.parentLastName}
                    onChange={(e) => handleInputChange("parentLastName", e.target.value)}
                    required
                  />
                </div>
              </div>
              
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="parentEmail">Email Address *</Label>
                  <Input
                    id="parentEmail"
                    type="email"
                    value={formData.parentEmail}
                    onChange={(e) => handleInputChange("parentEmail", e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="parentPhone">Phone Number *</Label>
                  <Input
                    id="parentPhone"
                    type="tel"
                    value={formData.parentPhone}
                    onChange={(e) => handleInputChange("parentPhone", e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label>Relationship to Student *</Label>
                  <Select onValueChange={(value) => handleInputChange("relationship", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select relationship" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mother">Mother</SelectItem>
                      <SelectItem value="father">Father</SelectItem>
                      <SelectItem value="guardian">Legal Guardian</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Required Documents */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Required Documents
              </CardTitle>
              <CardDescription>
                Please upload the required documents based on the grade you're applying for
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {formData.gradeApplying && (
                <div className="mb-4 p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
                  <h4 className="font-medium mb-2">Required for {formData.gradeApplying}:</h4>
                  <ul className="text-sm text-muted-foreground list-disc list-inside">
                    {getRequiredDocuments().includes('birthCertificate') && <li>Birth Certificate</li>}
                    {getRequiredDocuments().includes('immunizationRecords') && <li>Immunization Records</li>}
                    {getRequiredDocuments().includes('academicRecords') && <li>Academic Records (Last 2 Years)</li>}
                    {getRequiredDocuments().includes('teacherRecommendations') && <li>Teacher Recommendations</li>}
                    {getRequiredDocuments().includes('healthRecords') && <li>Health Records</li>}
                    {getRequiredDocuments().includes('passportCopy') && <li>Passport Copy</li>}
                  </ul>
                </div>
              )}
              
              <div className="grid md:grid-cols-2 gap-4">
                {getRequiredDocuments().includes('birthCertificate') && (
                  <div>
                    <Label htmlFor="birthCertificate">Birth Certificate *</Label>
                    <Input
                      id="birthCertificate"
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={(e) => handleFileChange("birthCertificate", e.target.files?.[0] || null)}
                      required
                    />
                  </div>
                )}
                
                {getRequiredDocuments().includes('immunizationRecords') && (
                  <div>
                    <Label htmlFor="immunizationRecords">Immunization Records *</Label>
                    <Input
                      id="immunizationRecords"
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={(e) => handleFileChange("immunizationRecords", e.target.files?.[0] || null)}
                      required
                    />
                  </div>
                )}
                
                {getRequiredDocuments().includes('academicRecords') && (
                  <div>
                    <Label htmlFor="academicRecords">Academic Records (Last 2 Years) *</Label>
                    <Input
                      id="academicRecords"
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={(e) => handleFileChange("academicRecords", e.target.files?.[0] || null)}
                      required
                    />
                  </div>
                )}
                
                {getRequiredDocuments().includes('teacherRecommendations') && (
                  <div>
                    <Label htmlFor="teacherRecommendations">Teacher Recommendations *</Label>
                    <Input
                      id="teacherRecommendations"
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={(e) => handleFileChange("teacherRecommendations", e.target.files?.[0] || null)}
                      required
                    />
                  </div>
                )}
                
                {getRequiredDocuments().includes('healthRecords') && (
                  <div>
                    <Label htmlFor="healthRecords">Health Records *</Label>
                    <Input
                      id="healthRecords"
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={(e) => handleFileChange("healthRecords", e.target.files?.[0] || null)}
                      required
                    />
                  </div>
                )}
                
                {getRequiredDocuments().includes('passportCopy') && (
                  <div>
                    <Label htmlFor="passportCopy">Passport Copy *</Label>
                    <Input
                      id="passportCopy"
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={(e) => handleFileChange("passportCopy", e.target.files?.[0] || null)}
                      required
                    />
                  </div>
                )}
              </div>
              
              <p className="text-sm text-muted-foreground">
                Accepted file formats: PDF, JPG, JPEG, PNG (Max size: 10MB per file)
              </p>
            </CardContent>
          </Card>

          {/* Additional Information */}
          <Card>
            <CardHeader>
              <CardTitle>Additional Information</CardTitle>
              <CardDescription>
                Help us get to know the student better
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="extracurriculars">Extracurricular Activities & Interests</Label>
                <Textarea
                  id="extracurriculars"
                  value={formData.extracurriculars}
                  onChange={(e) => handleInputChange("extracurriculars", e.target.value)}
                  placeholder="Please describe any sports, clubs, hobbies, or special interests..."
                  className="min-h-[100px]"
                />
              </div>
              
              <div>
                <Label htmlFor="personalStatement">Personal Statement</Label>
                <Textarea
                  id="personalStatement"
                  value={formData.personalStatement}
                  onChange={(e) => handleInputChange("personalStatement", e.target.value)}
                  placeholder="Why do you want to attend Kelson International School? What are your goals and aspirations?"
                  className="min-h-[120px]"
                />
              </div>
              
              <div>
                <Label htmlFor="specialNeeds">Special Needs or Accommodations</Label>
                <Textarea
                  id="specialNeeds"
                  value={formData.specialNeeds}
                  onChange={(e) => handleInputChange("specialNeeds", e.target.value)}
                  placeholder="Please describe any learning differences, medical conditions, or accommodations needed..."
                  className="min-h-[80px]"
                />
              </div>
            </CardContent>
          </Card>

          {/* Terms and Agreements */}
          <Card>
            <CardHeader>
              <CardTitle>Terms and Agreements</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="agreeToTerms"
                  checked={formData.agreeToTerms}
                  onCheckedChange={(checked) => handleInputChange("agreeToTerms", checked as boolean)}
                />
                <Label htmlFor="agreeToTerms" className="text-sm">
                  I agree to the school's terms and conditions and understand that all information provided is accurate *
                </Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="agreeToContact"
                  checked={formData.agreeToContact}
                  onCheckedChange={(checked) => handleInputChange("agreeToContact", checked as boolean)}
                />
                <Label htmlFor="agreeToContact" className="text-sm">
                  I consent to being contacted by Kelson International School regarding this application *
                </Label>
              </div>
            </CardContent>
          </Card>

          {/* Submit Button */}
          <div className="text-center">
            <Button 
              type="submit" 
              size="lg" 
              className="px-8"
              disabled={!formData.agreeToTerms || !formData.agreeToContact || isSubmitting}
            >
              {isSubmitting ? "Submitting..." : "Submit Application"}
            </Button>
            <p className="text-sm text-muted-foreground mt-2">
              * Required fields must be completed
            </p>
          </div>
        </form>
      </div>
    </main>
  );
}