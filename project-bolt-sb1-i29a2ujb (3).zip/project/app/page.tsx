import { Hero } from "@/components/ui/hero";
import StudentLife from "@/components/home/student-life";
import { CallToAction } from "@/components/home/call-to-action";

export default function Home() {
  return (
    <>
      <Hero
        backgroundImage="/IMG-20250515-WA0007 copy.jpg"
        title={
          <>
            Inspiring <span className="text-primary">Excellence</span>,<br />
            Empowering <span className="text-primary">Futures</span>
          </>
        }
        description="Kelson International School provides a transformative education experience that nurtures intellectual curiosity, character development, and lifelong learning."
        primaryAction={{
          text: "Apply Now",
          href: "/apply",
        }}
        secondaryAction={{
          text: "Learn More",
          href: "/about",
        }}
      />
      <StudentLife />
      <CallToAction />
    </>
  );
}