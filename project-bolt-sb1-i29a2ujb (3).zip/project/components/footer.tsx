import Link from "next/link";
import { School, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin, Youtube } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-gray-50 dark:bg-gray-900 border-t">
      <div className="container py-12 md:py-16">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-5">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2">
              <School className="h-8 w-8 text-blue-700 dark:text-blue-400" />
              <span className="font-bold text-xl">Kelson International School</span>
            </div>
            <p className="mt-4 text-muted-foreground max-w-xs">
              Kelson International School is dedicated to providing exceptional education through innovative teaching methods and a nurturing environment for all students.
            </p>
            <div className="mt-6 flex space-x-4">
              <Link 
                href="#" 
                className="text-muted-foreground hover:text-blue-700 dark:hover:text-blue-400 transition-colors"
              >
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link 
                href="#" 
                className="text-muted-foreground hover:text-blue-700 dark:hover:text-blue-400 transition-colors"
              >
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Link>
              <Link 
                href="#" 
                className="text-muted-foreground hover:text-blue-700 dark:hover:text-blue-400 transition-colors"
              >
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link 
                href="#" 
                className="text-muted-foreground hover:text-blue-700 dark:hover:text-blue-400 transition-colors"
              >
                <Linkedin className="h-5 w-5" />
                <span className="sr-only">LinkedIn</span>
              </Link>
              <Link 
                href="#" 
                className="text-muted-foreground hover:text-blue-700 dark:hover:text-blue-400 transition-colors"
              >
                <Youtube className="h-5 w-5" />
                <span className="sr-only">YouTube</span>
              </Link>
            </div>
          </div>
          <div>
            <h3 className="text-sm font-semibold">Quick Links</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-blue-700 dark:hover:text-blue-400 transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/academics" className="text-muted-foreground hover:text-blue-700 dark:hover:text-blue-400 transition-colors">
                  Academics
                </Link>
              </li>
              <li>
                <Link href="/admissions" className="text-muted-foreground hover:text-blue-700 dark:hover:text-blue-400 transition-colors">
                  Admissions
                </Link>
              </li>
              <li>
                <Link href="/school-life" className="text-muted-foreground hover:text-blue-700 dark:hover:text-blue-400 transition-colors">
                  School Life
                </Link>
              </li>
              <li>
                <Link href="/news" className="text-muted-foreground hover:text-blue-700 dark:hover:text-blue-400 transition-colors">
                  News & Events
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold">Resources</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <Link href="#" className="text-muted-foreground hover:text-blue-700 dark:hover:text-blue-400 transition-colors">
                  Student Portal
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-blue-700 dark:hover:text-blue-400 transition-colors">
                  Parent Portal
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-blue-700 dark:hover:text-blue-400 transition-colors">
                  Staff Directory
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-blue-700 dark:hover:text-blue-400 transition-colors">
                  Calendar
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-blue-700 dark:hover:text-blue-400 transition-colors">
                  Library
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold">Contact</h3>
            <ul className="mt-4 space-y-2">
              <li className="flex gap-2">
                <MapPin className="h-5 w-5 text-muted-foreground" />
                <span className="text-muted-foreground">123 Education Ave, Learning City, LC 12345</span>
              </li>
              <li className="flex gap-2">
                <Phone className="h-5 w-5 text-muted-foreground" />
                <span className="text-muted-foreground">(123) 456-7890</span>
              </li>
              <li className="flex gap-2">
                <Mail className="h-5 w-5 text-muted-foreground" />
                <span className="text-muted-foreground">info@kelson.edu</span>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-12 border-t pt-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Kelson International School. All rights reserved.
          </p>
          <div className="flex gap-4 text-sm text-muted-foreground">
            <Link href="#" className="hover:text-blue-700 dark:hover:text-blue-400 transition-colors">
              Privacy Policy
            </Link>
            <Link href="#" className="hover:text-blue-700 dark:hover:text-blue-400 transition-colors">
              Terms of Use
            </Link>
            <Link href="#" className="hover:text-blue-700 dark:hover:text-blue-400 transition-colors">
              Accessibility
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}