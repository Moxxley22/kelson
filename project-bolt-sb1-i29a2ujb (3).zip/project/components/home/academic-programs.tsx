import { BookOpen, GraduationCap, Microscope } from "lucide-react";
import Image from "next/image";
import { SectionHeading } from "@/components/ui/section-heading";
import { FeatureCard } from "@/components/ui/feature-card";

export function AcademicPrograms() {
  const programs = [
    {
      icon: <BookOpen className="h-6 w-6 text-primary" />,
      title: "Elementary School",
      description: "A foundation for lifelong learning with a focus on core skills, creativity, and character development for grades K-5.",
      image: "/IMG-20250515-WA0029.jpg"
    },
    {
      icon: <Microscope className="h-6 w-6 text-primary" />,
      title: "Middle School",
      description: "Engaging curriculum that challenges students intellectually while supporting their social and emotional growth for grades 6-8.",
      image: "/IMG-20250515-WA0007 copy.jpg"
    },
    {
      icon: <GraduationCap className="h-6 w-6 text-primary" />,
      title: "High School",
      description: "College preparatory education with advanced placement courses, leadership opportunities, and personalized guidance for grades 9-12.",
      image: "/IMG-20250513-WA0018.jpg"
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-secondary">
      <div className="container">
        <SectionHeading
          title="Academic Excellence"
          description="Our comprehensive academic programs are designed to inspire curiosity, foster critical thinking, and prepare students for future success."
        />
        <div className="grid gap-6 md:grid-cols-3">
          {programs.map((program, index) => (
            <div
              key={index}
              className="group relative flex flex-col overflow-hidden rounded-lg border bg-background transition-all hover:shadow-md"
            >
              <div className="relative h-48 w-full overflow-hidden">
                <Image
                  src={program.image}
                  alt={program.title}
                  fill
                  className="object-cover transition-transform duration-300 group-hover:scale-105"
                />
              </div>
              <div className="flex flex-col space-y-2 p-6">
                <div className="flex items-center gap-3 mb-2">
                  {program.icon}
                  <h3 className="text-xl font-semibold">{program.title}</h3>
                </div>
                <p className="text-muted-foreground">{program.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}