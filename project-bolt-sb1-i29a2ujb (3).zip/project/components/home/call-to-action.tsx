import Link from "next/link";
import { Button } from "@/components/ui/button";

export function CallToAction() {
  return (
    <section className="bg-primary text-white py-16">
      <div className="container text-center">
        <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">
          Begin Your Journey at Kelson International School
        </h2>
        <p className="text-lg text-primary-foreground/90 max-w-2xl mx-auto mb-8">
          Take the first step toward providing your child with an exceptional education experience. Apply now or contact us to learn more.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" className="bg-white text-primary hover:bg-primary-foreground" asChild>
            <Link href="/apply">Apply Now</Link>
          </Button>
          <Button size="lg" className="bg-white text-primary hover:bg-primary-foreground" asChild>
            <Link href="/contact">Schedule a Visit</Link>
          </Button>
        </div>
      </div>
    </section>
  );
}