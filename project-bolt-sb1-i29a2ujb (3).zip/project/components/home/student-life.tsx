"use client";

import Image from "next/image";
import { Card, CardContent } from "@/components/ui/card";
import { Activity, Book, Music, Users } from "lucide-react";

const activities = [
  {
    icon: <Users className="h-6 w-6 text-blue-500" />,
    title: "Student Clubs",
    description: "Join diverse clubs and organizations to pursue your interests and make lasting friendships.",
    image: "/IMG-20250515-WA0029.jpg"
  },
  {
    icon: <Activity className="h-6 w-6 text-green-500" />,
    title: "Sports & Athletics",
    description: "Participate in competitive sports and recreational activities to stay active and healthy.",
    image: "/IMG-20250515-WA0016.jpg"
  },
  {
    icon: <Music className="h-6 w-6 text-purple-500" />,
    title: "Arts & Culture",
    description: "Express yourself through music, theater, dance, and visual arts programs.",
    image: "/IMG-20250513-WA0021.jpg"
  },
  {
    icon: <Book className="h-6 w-6 text-red-500" />,
    title: "Academic Support",
    description: "Access tutoring, study groups, and academic resources to excel in your studies.",
    image: "/IMG-20250513-WA0019.jpg"
  }
];

export default function StudentLife() {
  return (
    <section className="py-16 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Student Life</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {activities.map((activity, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-6">
                <div className="relative h-48 w-full mb-4 rounded-lg overflow-hidden">
                  <Image
                    src={activity.image}
                    alt={activity.title}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="flex flex-col items-center text-center">
                  <div className="mb-4 p-3 bg-gray-100 rounded-full">
                    {activity.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{activity.title}</h3>
                  <p className="text-gray-600">{activity.description}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}