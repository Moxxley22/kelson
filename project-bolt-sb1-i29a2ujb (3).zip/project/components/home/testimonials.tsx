"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { cn } from "@/lib/utils";
import { SectionHeading } from "@/components/ui/section-heading";
import { ArrowLeft, ArrowRight, Quote } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Testimonial {
  quote: string;
  author: string;
  role: string;
  image: string;
}

export function Testimonials() {
  const testimonials: Testimonial[] = [
    {
      quote: "The faculty at Oakridge Academy truly cares about each student's success. My children have thrived academically and personally since enrolling here.",
      author: "Sarah Johnson",
      role: "Parent of Two Students",
      image: "https://images.pexels.com/photos/762020/pexels-photo-762020.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
    {
      quote: "Graduating from Oakridge prepared me exceptionally well for college. The rigorous academics and supportive teachers gave me the confidence and skills to succeed.",
      author: "Michael Chen",
      role: "Alumni, Class of 2023",
      image: "https://images.pexels.com/photos/1462980/pexels-photo-1462980.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
    {
      quote: "As an educator, I'm proud to be part of a school that values innovation and excellence. We truly nurture the whole student – intellectually, socially, and emotionally.",
      author: "Dr. James Wilson",
      role: "Science Department Chair",
      image: "https://images.pexels.com/photos/5711115/pexels-photo-5711115.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
  ];

  const [activeIndex, setActiveIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const goToNext = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setActiveIndex((prev) => (prev + 1) % testimonials.length);
    setTimeout(() => setIsAnimating(false), 500);
  };

  const goToPrev = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setActiveIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
    setTimeout(() => setIsAnimating(false), 500);
  };

  useEffect(() => {
    const interval = setInterval(goToNext, 8000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="py-16 md:py-24 bg-blue-50 dark:bg-blue-950/30">
      <div className="container">
        <SectionHeading
          title="What Our Community Says"
          description="Hear from parents, alumni, and faculty about the Oakridge Academy experience."
        />
        
        <div className="relative mx-auto max-w-4xl">
          <div className="h-[350px] md:h-[300px] overflow-hidden">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className={cn(
                  "absolute w-full transition-all duration-500 ease-in-out flex flex-col md:flex-row gap-8 items-center",
                  activeIndex === index
                    ? "opacity-100 translate-x-0"
                    : index < activeIndex
                    ? "opacity-0 -translate-x-full"
                    : "opacity-0 translate-x-full"
                )}
              >
                <div className="relative h-20 w-20 flex-none overflow-hidden rounded-full border-4 border-white shadow">
                  <Image
                    src={testimonial.image}
                    alt={testimonial.author}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="text-center md:text-left">
                  <Quote className="h-10 w-10 mx-auto md:mx-0 mb-4 text-blue-200 dark:text-blue-800" />
                  <p className="italic text-lg mb-4">{testimonial.quote}</p>
                  <div>
                    <p className="font-semibold">{testimonial.author}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-8 flex justify-center gap-4">
            <Button
              variant="outline"
              size="icon"
              onClick={goToPrev}
              className="rounded-full"
              disabled={isAnimating}
            >
              <ArrowLeft className="h-4 w-4" />
              <span className="sr-only">Previous</span>
            </Button>
            <div className="flex gap-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  className={cn(
                    "h-2 w-2 rounded-full transition-all",
                    activeIndex === index
                      ? "bg-blue-700 dark:bg-blue-400 w-6"
                      : "bg-blue-200 dark:bg-blue-800"
                  )}
                  onClick={() => {
                    if (isAnimating) return;
                    setIsAnimating(true);
                    setActiveIndex(index);
                    setTimeout(() => setIsAnimating(false), 500);
                  }}
                >
                  <span className="sr-only">Testimonial {index + 1}</span>
                </button>
              ))}
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={goToNext}
              className="rounded-full"
              disabled={isAnimating}
            >
              <ArrowRight className="h-4 w-4" />
              <span className="sr-only">Next</span>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}