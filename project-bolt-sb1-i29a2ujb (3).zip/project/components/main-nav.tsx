"use client"

import * as React from "react"
import Link from "next/link"
import { School } from "lucide-react"
import { cn } from "@/lib/utils"

export function MainNav() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <div className="mr-4 hidden md:flex">
          <Link href="/" className="mr-6 flex items-center space-x-2">
            <School className="h-6 w-6 text-primary" />
            <span className="hidden font-bold sm:inline-block">
              Kelson International School
            </span>
          </Link>
          <nav className="flex items-center space-x-6 text-sm font-medium">
            <Link
              href="/"
              className="transition-colors hover:text-foreground/80 text-foreground/60"
            >
              Home
            </Link>
            <Link
              href="/about"
              className="transition-colors hover:text-foreground/80 text-foreground/60"
            >
              About
            </Link>
            <Link
              href="/academics"
              className="transition-colors hover:text-foreground/80 text-foreground/60"
            >
              Academics
            </Link>
            <Link
              href="/admissions"
              className="transition-colors hover:text-foreground/80 text-foreground/60"
            >
              Admissions
            </Link>
            <Link
              href="/school-life"
              className="transition-colors hover:text-foreground/80 text-foreground/60"
            >
              School Life
            </Link>
            <Link
              href="/contact"
              className="transition-colors hover:text-foreground/80 text-foreground/60"
            >
              Contact
            </Link>
            <Link
              href="/apply"
              className="transition-colors hover:text-foreground/80 text-foreground/60"
            >
              Apply
            </Link>
            <Link
              href="/applications/status"
              className="transition-colors hover:text-foreground/80 text-foreground/60"
            >
              Check Status
            </Link>
          </nav>
        </div>
      </div>
    </header>
  )
}