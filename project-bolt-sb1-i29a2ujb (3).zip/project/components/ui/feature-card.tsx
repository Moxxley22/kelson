import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface FeatureCardProps {
  icon: ReactNode;
  title: string;
  description: string;
  className?: string;
}

export function FeatureCard({ 
  icon, 
  title, 
  description,
  className,
}: FeatureCardProps) {
  return (
    <div className={cn(
      "relative overflow-hidden rounded-lg border bg-background p-6 transition-all hover:shadow-md",
      className
    )}>
      <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-blue-50 dark:bg-blue-900/20">
        {icon}
      </div>
      <h3 className="mb-2 text-xl font-semibold">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </div>
  );
}