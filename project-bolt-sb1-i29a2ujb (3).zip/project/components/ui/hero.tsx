"use client";

import { ReactNode, useState, useEffect } from "react";
import Image from "next/image";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

interface HeroProps {
  backgroundImage: string;
  title: ReactNode;
  description: string;
  primaryAction?: {
    text: string;
    href: string;
  };
  secondaryAction?: {
    text: string;
    href: string;
  };
  overlay?: boolean;
  contentPosition?: "left" | "center" | "right";
  className?: string;
}

export function Hero({
  backgroundImage,
  title,
  description,
  primaryAction,
  secondaryAction,
  overlay = true,
  contentPosition = "center",
  className,
}: HeroProps) {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div 
      className={cn(
        "relative min-h-[70vh] w-full flex items-center",
        className
      )}
    >
      <div className="absolute inset-0 w-full h-full z-0">
        <Image
          src={backgroundImage}
          alt="Background"
          fill
          priority
          sizes="100vw"
          className="object-cover"
        />
        {overlay && (
          <div className="absolute inset-0 bg-black/40 dark:bg-black/60" />
        )}
      </div>
      
      <div className={cn(
        "container relative z-10",
        contentPosition === "center" && "text-center",
        contentPosition === "right" && "text-right"
      )}>
        <div className={cn(
          "max-w-3xl transition-all duration-1000 ease-in-out",
          contentPosition === "center" && "mx-auto",
          contentPosition === "right" && "ml-auto",
          isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
        )}>
          <div className="text-white space-y-4">
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
              {title}
            </h1>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              {description}
            </p>
            {(primaryAction || secondaryAction) && (
              <div className={cn(
                "flex gap-4 mt-8",
                contentPosition === "center" && "justify-center",
                contentPosition === "right" && "justify-end"
              )}>
                {primaryAction && (
                  <Button size="lg" asChild>
                    <a href={primaryAction.href}>{primaryAction.text}</a>
                  </Button>
                )}
                {secondaryAction && (
                  <Button size="lg" variant="outline" className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20" asChild>
                    <a href={secondaryAction.href}>{secondaryAction.text}</a>
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}