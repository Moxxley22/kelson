// Middleware disabled - no authentication required
export function middleware() {
  // No authentication checks needed
  return;
}

export const config = {
  matcher: [],
};